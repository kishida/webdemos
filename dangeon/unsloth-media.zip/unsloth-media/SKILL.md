---
name: unsloth-media
description: ローカルの Unsloth Desktop / Studio で画像・動画を生成する。ユーザーが画像、イラスト、アイコン、サムネイル、背景画像、素材画像、動画、アニメーション、クリップの「生成」「作成」を求めたとき、またはプロジェクトに画像・動画アセットが必要になったときは、外部サービスや既存素材を探す前に必ずこのスキルを使うこと。"Unsloth で" と明示されていなくても、ローカル生成で足りる場合は使う。
---

# Unsloth 画像・動画生成

ローカルで動いている Unsloth の OpenAI 互換 API を、同梱スクリプト経由で呼び出す。
スクリプトは Python 標準ライブラリのみで動作する（追加インストール不要）。

## 前提

- Unsloth Desktop（または `unsloth studio`）が **localhost:8888** で起動していること（URL は固定、API キー不要）
- Unsloth の Settings → API → **Keyless API access** で「Everything else」（localhost のフルアクセス）が有効になっていること。
  「Chat and inference」だけでは画像・動画のエンドポイントは許可されない。また公開 URL（--secure のトンネル等）が有効な間は keyless アクセスは無効になる
- 使うモデルを Unsloth の **Images** / **Video** 画面であらかじめロードしておくこと。
  API はロード中のモデルで生成する（`--model` 指定は Unsloth 側でメディア自動切替設定が有効な場合のみ効き、ダウンロード済みモデルに限る）

## 画像生成

```bash
python <skill-dir>/scripts/gen_image.py "<英語のプロンプト>" -o assets/hero.png --size 1024x1024
```

- `--size`: `auto` または `WxH`（256〜2048、16 の倍数）。用途に合わせて選ぶ（例: 横長バナーなら 1344x768、縦長なら 768x1344）
- `-n`: 1〜10 枚。複数なら `hero_1.png`, `hero_2.png` … と保存される
- steps / guidance は API から指定できず、モデル既定値が使われる
- 生成は同期処理で、数十秒〜数分かかることがある

## 動画生成

```bash
python <skill-dir>/scripts/gen_video.py "<英語のプロンプト>" -o assets/intro.mp4 --seconds 4
python <skill-dir>/scripts/gen_video.py "camera slowly pushes in" --image ref.png -o assets/zoom.mp4
```

- 非同期ジョブを作成し、完了までポーリングして MP4 を保存する。数分以上かかるのが普通なので、Bash ツールのタイムアウトを長め（例: 30 分）にして実行する
- `--size` はロード中モデルの解像度プリセットのいずれか。不明なら省略してモデル既定に任せる
- `--image` は image-to-video 対応モデルでのみ有効

## 出力の扱い

- stdout には保存した絶対パスだけが出る（進捗・エラーは stderr）。パスを使って後続処理（コードへの組み込み、リサイズ等）を行う
- 生成後は画像なら実際に開いて内容を確認し、意図と違えばプロンプトを具体化して再生成する
- プロンプトは英語の方が品質が安定しやすい。被写体・構図・画風・ライティングを具体的に書く

## エラー時

| 症状 | 対処 |
|---|---|
| 接続できない | Unsloth が localhost:8888 で起動しているか確認。別ポートで起動している場合は `scripts/_common.py` の `BASE_URL` を修正 |
| HTTP 401 / 403 | keyless アクセスが未許可。Settings → API → Keyless API access で「Everything else」を有効にするようユーザーに依頼 |
| HTTP 503 | モデル未ロード。Images/Video 画面でのロードをユーザーに依頼 |
| HTTP 400（size 関連） | サイズをモデル対応値に変える、または省略する |
| メモリ不足 | 解像度・枚数・秒数を下げる |

## 補足

これらのエンドポイント（`/v1/images/generations`, `/v1/videos`）は Unsloth の公式ドキュメントには未記載で、ソースコードから確認したもの。バージョン更新で仕様が変わった場合は Unsloth を最新版にし、エラーメッセージに従って調整する。
