#!/usr/bin/env python3
"""Unsloth でテキストから画像を生成して PNG で保存する。

例: python gen_image.py "koi pond, watercolor" -o out/koi.png --size 1024x1024 -n 2
"""
import argparse
import base64
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import die, request  # noqa: E402


def main():
    p = argparse.ArgumentParser(description="Unsloth 画像生成 (POST /v1/images/generations)")
    p.add_argument("prompt")
    p.add_argument("-o", "--output", default="image.png", help="出力パス。n>1 なら _1, _2… を付与")
    p.add_argument("--size", default="auto", help="'auto' または WxH（256〜2048、16の倍数）")
    p.add_argument("-n", type=int, default=1, help="枚数 (1-10)")
    p.add_argument("--model", help="モデル名（自動切替設定が有効な場合のみ有効）")
    a = p.parse_args()

    if not 1 <= a.n <= 10:
        die("-n は 1〜10 で指定してください")
    payload = {"prompt": a.prompt, "n": a.n, "size": a.size, "response_format": "b64_json"}
    if a.model:
        payload["model"] = a.model

    print(f"生成中… ({a.n}枚, size={a.size})", file=sys.stderr)
    res = request("POST", "/v1/images/generations", payload, timeout=1800)
    items = res.get("data") or []
    if not items:
        die(f"画像が返りませんでした: {res}")

    out_dir = os.path.dirname(os.path.abspath(a.output))
    os.makedirs(out_dir, exist_ok=True)
    stem, ext = os.path.splitext(a.output)
    ext = ext or ".png"
    for i, item in enumerate(items, 1):
        path = f"{stem}{ext}" if len(items) == 1 else f"{stem}_{i}{ext}"
        with open(path, "wb") as f:
            f.write(base64.b64decode(item["b64_json"]))
        print(os.path.abspath(path))  # stdout には保存パスのみ


if __name__ == "__main__":
    main()
