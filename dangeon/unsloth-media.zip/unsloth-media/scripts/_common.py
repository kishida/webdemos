"""Unsloth API 共通ヘルパー（標準ライブラリのみ）。"""
import json
import sys
import urllib.error
import urllib.request

BASE_URL = "http://localhost:8888"


def die(msg, code=1):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(code)


def _error_message(raw):
    try:
        body = json.loads(raw)
        err = body.get("error") or body.get("detail") or body
        if isinstance(err, dict):
            return err.get("message") or json.dumps(err, ensure_ascii=False)
        return str(err)
    except Exception:
        return raw[:500]


def request(method, path, payload=None, timeout=600, raw=False):
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(f"{BASE_URL}{path}", data=data, method=method)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read()
            return body if raw else json.loads(body)
    except urllib.error.HTTPError as e:
        msg = _error_message(e.read().decode(errors="replace"))
        hint = ""
        if e.code in (401, 403):
            hint = ("（キーなしアクセスが許可されていません。Unsloth の Settings → API → "
                    "Keyless API access で「Everything else」(localhost のフルアクセス) を有効にしてください）")
        elif e.code == 503:
            hint = "（モデル未ロード。Unsloth の Images/Video 画面でモデルをロードしてください）"
        die(f"HTTP {e.code}{hint}: {msg}")
    except urllib.error.URLError as e:
        die(f"{BASE_URL} に接続できません: {e.reason}。Unsloth が localhost:8888 で起動しているか確認してください")


def image_to_data_url(path):
    import base64
    import mimetypes
    mime = mimetypes.guess_type(path)[0] or "image/png"
    with open(path, "rb") as f:
        return f"data:{mime};base64,{base64.b64encode(f.read()).decode()}"
