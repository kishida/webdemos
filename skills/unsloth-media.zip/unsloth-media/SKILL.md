---
name: unsloth-media
description: ローカルの Unsloth Desktop / Studio で画像の生成・編集と動画生成を行う。ユーザーが画像、イラスト、アイコン、写真の加工・編集・描き直し、サムネイル、背景画像、素材画像、動画、アニメーション、クリップの「生成」「作成」、または既存画像の編集・加工（画風変更、背景差し替え、一部の描き直し、季節や時間帯の変更など）を求めたとき、またはプロジェクトに画像・動画アセットが必要になったときは、外部サービスや既存素材を探す前に必ずこのスキルを使うこと。"Unsloth で" と明示されていなくても、ローカル生成で足りる場合は使う。
---

# Unsloth 画像・動画生成

ローカルで動いている Unsloth の API を、同梱スクリプト経由で呼び出す。
画像は GUI と同じ内部 API（`/api/inference/images/generate`）、動画は OpenAI 互換 API（`/v1/videos`）を使う。
スクリプトは Python 標準ライブラリのみで動作する（追加インストール不要）。

## 前提

- Unsloth Desktop（または `unsloth studio`）が起動していること
- Unsloth の Settings → API → **Keyless API access** で「**Everything else**」が ON になっていること。
  「Chat and inference」だけでは画像・動画のエンドポイントは許可されない
- 使うモデルを Unsloth の **Images** / **Video** 画面であらかじめロードしておくこと
- 接続先は既定で `http://localhost:8888`。`set_url.py` で保存した URL があればそちらを使う（スキル直下の `unsloth_url.txt`）
- API キーは `set_key.py` で保存したものがあれば自動で送る（スキル直下の `unsloth_key.txt`）。LAN 経由で接続する場合は必要

## 最初に疎通確認

生成の前に、まず接続を確認する:

```bash
python <skill-dir>/scripts/set_url.py
```

`OK` が出れば生成に進む。`NG` なら次の「接続できないとき」の手順に従う。

## 接続できないとき（必ずこの順で確認する）

Mac では localhost で Unsloth に届かないことが多い。接続エラーや HTTP 401 / 403 が出たら、
自分で URL を推測したりポートを総当たりしたりせず、ユーザーに次の順で確認を依頼する。

1. **Everything else が ON か**
   Unsloth の Settings → API → Keyless API access で「Everything else」が ON になっているか確認してもらう。
   ON にしたら `set_url.py` で再確認する
2. **それでも繋がらなければ LAN access が Start されているか**
   Unsloth の Settings の Remote / LAN 設定で、
   - LAN access を Start するには **Remote password の設定が必要**なので、未設定なら先に設定してもらう
   - そのうえで **LAN access を Start** してもらう
3. **Network address を貼り付けてもらう**
   LAN access の画面に表示される **Network address をコピーして、チャットに貼り付けてもらう**。
   受け取ったアドレスをそのまま保存して疎通確認する:
   ```bash
   python <skill-dir>/scripts/set_url.py <貼り付けられた Network address>
   ```
   localhost に戻すときは `set_url.py --reset`
4. **API キーを作成して貼り付けてもらう**（3 の結果が「認証が必要です (HTTP 401/403)」のとき）
   Unsloth の Settings → API で、キー名に **`claude-access`** と入力して Create してもらい、
   表示された **`sk-unsloth-…` をコピーしてチャットに貼り付けてもらう**（キーは作成時に一度しか表示されない）。
   受け取ったキーを保存して疎通確認する:
   ```bash
   python <skill-dir>/scripts/set_key.py <貼り付けられた API キー>
   ```
   `OK` になれば以後のスクリプトは URL とキーを自動で使う（保存されるので次回以降も有効）。
   「API キーが拒否されました」と出たら、キーのコピー漏れか失効なので作り直してもらう。削除は `set_key.py --clear`

ユーザーへの依頼は1ステップずつ行い、各ステップの後に `set_url.py` で結果を確かめてから次へ進む。
LAN access を止めたり Network address（IP）が変わったりすると繋がらなくなるので、そのときも同じ手順で URL を貼り直してもらう。

## 画像生成

```bash
python <skill-dir>/scripts/gen_image.py "<英語のプロンプト>" -o assets/hero.png --size 1024x1024
python <skill-dir>/scripts/gen_image.py "<プロンプト>" -o assets/hero.png --steps 30 --guidance 4 --seed 42 --negative "blurry, text"
```

- `--size`: `WxH`（16 の倍数）。省略時（`auto`）は 1024x1024。用途に合わせて選ぶ（例: 横長バナーなら 1344x768、縦長なら 768x1344）
- `-n`: 1〜10 枚。複数なら `hero_1.png`, `hero_2.png` … と保存される
- `--steps`（1〜100、**既定 20**）/ `--guidance`（0〜20、**既定 1.0**）/ `--seed` / `--negative` は任意。
  ユーザーから特に指示がなければ既定値のまま使う。`--seed` と `-n` を併用すると seed, seed+1, … が各画像に割り当てられる
- 生成は同期処理で、数十秒〜数分かかることがある

## 画像編集

```bash
# edit: プロンプトを編集指示として解釈（Kontext / Qwen-Image-Edit / FLUX.2 など編集対応モデルが必要）
python <skill-dir>/scripts/gen_edit.py photo.png "make it night, add neon signs" -o out/night.png
# 参照画像を追加（edit のみ・複数可）
python <skill-dir>/scripts/gen_edit.py person.png "put this person in the cafe" --ref cafe.png -o out/cafe.png
# img2img: 元画像をベースに描き直す（strength 小さいほど元に近い、既定 0.6）
python <skill-dir>/scripts/gen_edit.py photo.png "oil painting style" --strength 0.5 -o out/oil.png
# inpaint: マスクの白部分だけ描き直す（黒は維持）
python <skill-dir>/scripts/gen_edit.py photo.png "a red sports car" --mask mask.png -o out/car.png
```

- reference: `--mode reference` で、元画像（と `--ref`）を参考に新しい画像を生成する
- モードは `--mode edit|img2img|inpaint|reference` で明示できる。省略時は `--mask` があれば inpaint、`--strength` があれば img2img、それ以外は edit
- 出力サイズは省略すると元画像に合わせる（16 の倍数に丸め）。`--size WxH` で上書き可
- `--steps` / `--guidance` / `--seed` / `--negative` は画像生成と同じ
- どのモードが使えるかはロード中モデル次第。非対応ならエラーメッセージで分かるので、ユーザーにモデル変更を依頼する
- 編集前に元画像を、編集後に結果を実際に見て比較し、指示が反映されているか確認する

## 動画生成

```bash
python <skill-dir>/scripts/gen_video.py "<英語のプロンプト>" -o assets/intro.mp4 --seconds 4
python <skill-dir>/scripts/gen_video.py "camera slowly pushes in" --image ref.png -o assets/zoom.mp4
```

- 非同期ジョブを作成し、完了までポーリングして MP4 を保存する。数分以上かかるのが普通なので、Bash ツールのタイムアウトを長め（例: 30 分）にして実行する
- `--size` はロード中モデルの解像度プリセットのいずれか。不明なら省略してモデル既定に任せる
- `--image` は image-to-video 対応モデルでのみ有効

## 出力の扱い

- API キーは `set_key.py` 経由でのみ扱う。コード・CLAUDE.md・コミット対象のファイルに書き込んだり、ログやチャットに全文を再掲したりしない

- stdout には保存した絶対パスだけが出る（進捗・エラーは stderr）。パスを使って後続処理（コードへの組み込み、リサイズ等）を行う
- 生成後は画像なら実際に開いて内容を確認し、意図と違えばプロンプトを具体化して再生成する
- 画像は GUI 経由と同じくギャラリーにも保存されるので、ユーザーは Unsloth の画面でも確認できる
- プロンプトは英語の方が品質が安定しやすい。被写体・構図・画風・ライティングを具体的に書く

## エラー時

| 症状 | 対処 |
|---|---|
| 接続できない | 「接続できないとき」の手順 1→2→3 に従う |
| HTTP 401 / 403 | 同上。キー未設定なら手順 4 で claude-access キーを作成・保存。キー保存済みなら作り直してもらう |
| HTTP 503 | モデル未ロード。Images/Video 画面でのロードをユーザーに依頼 |
| HTTP 400 | メッセージに従う（モデルが非対応のモード、参照画像の枚数超過、サイズがモデルの範囲外など） |
| HTTP 409 | モデル未ロード、または別の生成が実行中。ロード状態を確認し、少し待って再実行 |
| HTTP 422 | パラメータの範囲外。メッセージに出た項目を直す |
| メモリ不足 | 解像度・枚数・秒数を下げる |

## 補足

使っているエンドポイントはどれも Unsloth の公式ドキュメントには未記載で、ソースコードから確認したもの。

- 画像生成・編集: `/api/inference/images/generate`（GUI 用の内部 API。特に変更されやすい）
- 動画生成: `/v1/videos`（OpenAI 互換）

steps / guidance の既定値（20 / 1.0）は `scripts/_common.py` の `DEFAULT_STEPS` / `DEFAULT_GUIDANCE` で変更できる。バージョン更新で仕様が変わった場合は Unsloth を最新版にし、エラーメッセージに従って調整する。
