---
name: unsloth-media
description: ローカルの Unsloth Desktop / Studio で画像の生成・編集と動画生成を行う。ユーザーが画像、イラスト、アイコン、写真の加工・編集・描き直し、サムネイル、背景画像、素材画像、動画、アニメーション、クリップの「生成」「作成」、または既存画像の編集・加工（画風変更、背景差し替え、一部の描き直し、季節や時間帯の変更など）を求めたとき、またはプロジェクトに画像・動画アセットが必要になったときは、外部サービスや既存素材を探す前に必ずこのスキルを使うこと。"Unsloth で" と明示されていなくても、ローカル生成で足りる場合は使う。
---

# Unsloth 画像・動画生成

ローカルで動いている Unsloth の API を、同梱スクリプト経由で呼び出す。
画像は GUI と同じ内部 API（`/api/inference/images/generate`）、動画は OpenAI 互換 API（`/v1/videos`）を使う。
スクリプトは Python 標準ライブラリのみで動作する（追加インストール不要）。

## 前提

- Unsloth Desktop（または `unsloth studio`）が **localhost:8888** で起動していること（URL は固定、API キー不要）
- Unsloth の Settings → API → **Keyless API access** で「Everything else」（localhost のフルアクセス）が有効になっていること。
  「Chat and inference」だけでは画像・動画のエンドポイントは許可されない。また公開 URL（--secure のトンネル等）が有効な間は keyless アクセスは無効になる
- 使うモデルを Unsloth の **Images** / **Video** 画面であらかじめロードしておくこと。
  API はロード中のモデルで生成する（`--model` 指定は Unsloth 側でメディア自動切替設定が有効な場合のみ効き、ダウンロード済みモデルに限る）

## 画像生成

```bash
python <skill-dir>/scripts/gen_image.py "<英語のプロンプト>" -o assets/hero.png --size 1024x1024
python <skill-dir>/scripts/gen_image.py "<プロンプト>" -o assets/hero.png --steps 30 --guidance 4 --seed 42 --negative "blurry, text"
```

- `--size`: `WxH`（16 の倍数）。省略時（`auto`）は 1024x1024。用途に合わせて選ぶ（例: 横長バナーなら 1344x768、縦長なら 768x1344）
- `-n`: 1〜10 枚。複数なら `hero_1.png`, `hero_2.png` … と保存される
- `--steps`（1〜100、**既定 20**）/ `--guidance`（0〜20、**既定 1.0**）/ `--seed` / `--negative` は任意。
  ユーザーから特に指示がなければ既定値のまま使う。`--seed` と `-n` を併用すると seed, seed+1, … が各画像に割り当てられる
- 生成は同期処理で、数十秒〜数分かかることがある

## 画像編集

```bash
# edit: プロンプトを編集指示として解釈（Kontext / Qwen-Image-Edit / FLUX.2 など編集対応モデルが必要）
python <skill-dir>/scripts/gen_edit.py photo.png "make it night, add neon signs" -o out/night.png
# 参照画像を追加（edit のみ・複数可）
python <skill-dir>/scripts/gen_edit.py person.png "put this person in the cafe" --ref cafe.png -o out/cafe.png
# img2img: 元画像をベースに描き直す（strength 小さいほど元に近い、既定 0.6）
python <skill-dir>/scripts/gen_edit.py photo.png "oil painting style" --strength 0.5 -o out/oil.png
# inpaint: マスクの白部分だけ描き直す（黒は維持）
python <skill-dir>/scripts/gen_edit.py photo.png "a red sports car" --mask mask.png -o out/car.png
```

- reference: `--mode reference` で、元画像（と `--ref`）を参考に新しい画像を生成する
- モードは `--mode edit|img2img|inpaint|reference` で明示できる。省略時は `--mask` があれば inpaint、`--strength` があれば img2img、それ以外は edit
- 出力サイズは省略すると元画像に合わせる（16 の倍数に丸め）。`--size WxH` で上書き可
- `--steps` / `--guidance` / `--seed` / `--negative` は画像生成と同じ
- どのモードが使えるかはロード中モデル次第。非対応ならエラーメッセージで分かるので、ユーザーにモデル変更を依頼する
- 編集前に元画像を、編集後に結果を実際に見て比較し、指示が反映されているか確認する

## 動画生成

```bash
python <skill-dir>/scripts/gen_video.py "<英語のプロンプト>" -o assets/intro.mp4 --seconds 4
python <skill-dir>/scripts/gen_video.py "camera slowly pushes in" --image ref.png -o assets/zoom.mp4
```

- 非同期ジョブを作成し、完了までポーリングして MP4 を保存する。数分以上かかるのが普通なので、Bash ツールのタイムアウトを長め（例: 30 分）にして実行する
- `--size` はロード中モデルの解像度プリセットのいずれか。不明なら省略してモデル既定に任せる
- `--image` は image-to-video 対応モデルでのみ有効

## 出力の扱い

- stdout には保存した絶対パスだけが出る（進捗・エラーは stderr）。パスを使って後続処理（コードへの組み込み、リサイズ等）を行う
- 生成後は画像なら実際に開いて内容を確認し、意図と違えばプロンプトを具体化して再生成する
- 画像は GUI 経由と同じくギャラリーにも保存されるので、ユーザーは Unsloth の画面でも確認できる
- プロンプトは英語の方が品質が安定しやすい。被写体・構図・画風・ライティングを具体的に書く

## エラー時

| 症状 | 対処 |
|---|---|
| 接続できない | Unsloth が localhost:8888 で起動しているか確認。別ポートで起動している場合は `scripts/_common.py` の `BASE_URL` を修正 |
| HTTP 401 / 403 | keyless アクセスが未許可。Settings → API → Keyless API access で「Everything else」を有効にするようユーザーに依頼 |
| HTTP 503 | モデル未ロード。Images/Video 画面でのロードをユーザーに依頼 |
| HTTP 400 | メッセージに従う（モデルが非対応のモード、参照画像の枚数超過、サイズがモデルの範囲外など） |
| HTTP 409 | モデル未ロード、または別の生成が実行中。ロード状態を確認し、少し待って再実行 |
| HTTP 422 | パラメータの範囲外。メッセージに出た項目を直す |
| メモリ不足 | 解像度・枚数・秒数を下げる |

## 補足

使っているエンドポイントはどれも Unsloth の公式ドキュメントには未記載で、ソースコードから確認したもの。

- 画像生成・編集: `/api/inference/images/generate`（GUI 用の内部 API。特に変更されやすい）
- 動画生成: `/v1/videos`（OpenAI 互換）

steps / guidance の既定値（20 / 1.0）は `scripts/_common.py` の `DEFAULT_STEPS` / `DEFAULT_GUIDANCE` で変更できる。バージョン更新で仕様が変わった場合は Unsloth を最新版にし、エラーメッセージに従って調整する。
