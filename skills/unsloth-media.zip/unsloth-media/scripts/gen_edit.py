#!/usr/bin/env python3
"""Unsloth で既存画像を編集して PNG で保存する（内部 API /api/inference/images/generate）。

モード（--mode 省略時は自動判定: --mask あり→inpaint、--strength あり→img2img、それ以外→edit）
  edit    : プロンプトを「指示」として画像を編集（Kontext / Qwen-Image-Edit / FLUX.2 など編集対応モデル）
  img2img : 元画像をベースに描き直す。--strength で元画像からの離れ具合 (0<x≤1)
  inpaint : --mask の白い部分だけ描き直す（黒は維持）
  reference: 元画像（と --ref）を参考に新しい画像を生成（--mode reference で明示）

例: python gen_edit.py photo.png "make it night, add neon signs" -o out/night.png
    python gen_edit.py photo.png "oil painting" --strength 0.5 -o out/oil.png
    python gen_edit.py photo.png "a red sports car" --mask mask.png -o out/car.png
    python gen_edit.py person.png "put this person in the cafe" --ref cafe.png -o out/cafe.png
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import (  # noqa: E402
    die, fit_size, image_size, image_to_data_url, parse_size, resolve_defaults, studio_generate,
)


def main():
    p = argparse.ArgumentParser(description="Unsloth 画像編集")
    p.add_argument("image", help="元画像")
    p.add_argument("prompt", help="edit では編集指示、img2img/inpaint では描く内容")
    p.add_argument("-o", "--output", default="edited.png")
    p.add_argument("--mode", choices=["edit", "img2img", "inpaint", "reference"], help="省略時は自動判定")
    p.add_argument("--mask", help="inpaint 用マスク（白=描き直す、黒=維持）")
    p.add_argument("--strength", type=float, help="img2img/inpaint の強さ (0<x≤1)")
    p.add_argument("--ref", action="append", default=[], help="追加の参照画像（edit/reference 用、複数可）")
    p.add_argument("--size", help="出力 WxH。省略時は元画像に合わせる")
    p.add_argument("--steps", type=int, help="ステップ数 (1-100)。既定 20")
    p.add_argument("--guidance", type=float, help="CFG スケール (0-20)。既定 1.0")
    p.add_argument("--seed", type=int)
    p.add_argument("--negative", help="ネガティブプロンプト（対応モデルのみ）")
    a = p.parse_args()

    mode = a.mode or ("inpaint" if a.mask else "img2img" if a.strength is not None else "edit")
    if mode == "inpaint" and not a.mask:
        die("inpaint には --mask が必要です")
    if a.strength is not None and not 0 < a.strength <= 1:
        die("--strength は 0 より大きく 1 以下で指定してください")
    if a.steps is not None and not 1 <= a.steps <= 100:
        die("--steps は 1〜100 で指定してください")
    if a.ref and mode not in ("edit", "reference"):
        die("--ref は edit / reference モードでのみ使えます")

    steps, guidance = resolve_defaults(a.steps, a.guidance)
    payload = {
        "prompt": a.prompt,
        "init_image": image_to_data_url(a.image),
        "steps": steps,
        "guidance": guidance,
    }
    if mode in ("edit", "reference"):
        payload["workflow"] = mode
        if a.ref:
            payload["reference_images"] = [image_to_data_url(r) for r in a.ref]
    if mode == "inpaint":
        payload["mask_image"] = image_to_data_url(a.mask)
    if mode in ("img2img", "inpaint"):
        payload["strength"] = a.strength if a.strength is not None else (0.6 if mode == "img2img" else 1.0)

    if a.size:
        payload["width"], payload["height"] = parse_size(a.size)
    elif mode in ("img2img", "inpaint"):
        # edit はサーバー側で元画像サイズに合わせる。他は既定 1024x1024 になるため元画像から算出
        dims = image_size(a.image)
        if dims:
            payload["width"], payload["height"] = fit_size(*dims)
    if a.seed is not None:
        payload["seed"] = a.seed
    if a.negative:
        payload["negative_prompt"] = a.negative

    print(f"{mode} 中… (steps={steps}, guidance={guidance}"
          + (f", strength={payload['strength']}" if "strength" in payload else "") + ")", file=sys.stderr)
    studio_generate(payload, a.output)


if __name__ == "__main__":
    main()
