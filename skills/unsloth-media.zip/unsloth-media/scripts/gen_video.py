#!/usr/bin/env python3
"""Unsloth で動画を生成し、完了まで待って MP4 で保存する。

例: python gen_video.py "a sloth surfing at sunset" -o out/sloth.mp4 --seconds 4
    python gen_video.py "camera slowly zooms in" --image ref.png -o out/zoom.mp4
"""
import argparse
import os
import sys
import time

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import die, image_to_data_url, request  # noqa: E402


def main():
    p = argparse.ArgumentParser(description="Unsloth 動画生成 (POST /v1/videos)")
    p.add_argument("prompt")
    p.add_argument("-o", "--output", default="video.mp4")
    p.add_argument("--seconds", help="長さ（秒）。モデルのフレーム刻みに丸められる")
    p.add_argument("--size", help="WxH。ロード中モデルの解像度プリセットのいずれか")
    p.add_argument("--image", help="リファレンス画像（image-to-video 対応モデル用）")
    p.add_argument("--model", help="モデル名（自動切替設定が有効な場合のみ有効）")
    p.add_argument("--poll", type=float, default=5.0, help="ポーリング間隔（秒）")
    p.add_argument("--timeout", type=float, default=3600, help="最大待ち時間（秒）")
    a = p.parse_args()

    payload = {"prompt": a.prompt}
    for key in ("seconds", "size", "model"):
        if getattr(a, key):
            payload[key] = str(getattr(a, key))
    if a.image:
        if not os.path.isfile(a.image):
            die(f"画像が見つかりません: {a.image}")
        payload["input_reference"] = image_to_data_url(a.image)

    job = request("POST", "/v1/videos", payload, timeout=300)
    vid = job["id"]
    print(f"ジョブ作成: {vid} (size={job.get('size')}, seconds={job.get('seconds')})", file=sys.stderr)

    deadline = time.time() + a.timeout
    last = None
    while True:
        job = request("GET", f"/v1/videos/{vid}", timeout=60)
        status, progress = job.get("status"), job.get("progress", 0)
        if (status, progress) != last:
            print(f"  {status} {progress}%", file=sys.stderr)
            last = (status, progress)
        if status == "completed":
            break
        if status == "failed":
            err = job.get("error") or {}
            die(f"生成失敗 [{err.get('code')}]: {err.get('message')}")
        if time.time() > deadline:
            die(f"タイムアウト（ジョブ {vid} はサーバー側で継続中の可能性あり）")
        time.sleep(a.poll)

    data = request("GET", f"/v1/videos/{vid}/content", timeout=600, raw=True)
    out_dir = os.path.dirname(os.path.abspath(a.output))
    os.makedirs(out_dir, exist_ok=True)
    with open(a.output, "wb") as f:
        f.write(data)
    print(os.path.abspath(a.output))  # stdout には保存パスのみ


if __name__ == "__main__":
    main()
