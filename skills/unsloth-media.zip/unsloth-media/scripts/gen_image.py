#!/usr/bin/env python3
"""Unsloth でテキストから画像を生成して PNG で保存する。

例: python gen_image.py "koi pond, watercolor" -o out/koi.png --size 1024x1024 -n 2
    python gen_image.py "koi pond" -o out/koi.png --steps 30 --guidance 4 --seed 42 --negative "blurry"

steps / guidance の既定値は 20 / 1.0（_common.py の DEFAULT_STEPS / DEFAULT_GUIDANCE）。
内部 API /api/inference/images/generate を使う。
"""
import argparse
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from _common import die, parse_size, resolve_defaults, studio_generate  # noqa: E402


def main():
    p = argparse.ArgumentParser(description="Unsloth 画像生成")
    p.add_argument("prompt")
    p.add_argument("-o", "--output", default="image.png", help="出力パス。複数枚なら _1, _2… を付与")
    p.add_argument("--size", default="auto", help="WxH（16の倍数）。'auto' は 1024x1024")
    p.add_argument("-n", type=int, default=1, help="枚数 (1-10)")
    p.add_argument("--steps", type=int, help="ステップ数 (1-100)。既定 20")
    p.add_argument("--guidance", type=float, help="CFG スケール (0-20)。既定 1.0")
    p.add_argument("--seed", type=int, help="シード（再現用）")
    p.add_argument("--negative", help="ネガティブプロンプト（対応モデルのみ）")
    a = p.parse_args()

    if not 1 <= a.n <= 10:
        die("-n は 1〜10 で指定してください")

    if a.steps is not None and not 1 <= a.steps <= 100:
        die("--steps は 1〜100 で指定してください")
    if a.guidance is not None and not 0 <= a.guidance <= 20:
        die("--guidance は 0〜20 で指定してください")
    steps, guidance = resolve_defaults(a.steps, a.guidance)
    payload = {"prompt": a.prompt, "steps": steps, "guidance": guidance}
    if a.size != "auto":
        payload["width"], payload["height"] = parse_size(a.size)
    if a.negative:
        payload["negative_prompt"] = a.negative
    if a.seed is not None:
        # 複数枚のときは seed, seed+1, … で各画像を個別に再現可能にする
        if a.n > 1:
            payload["seeds"] = [a.seed + i for i in range(a.n)]
        else:
            payload["seed"] = a.seed
    elif a.n > 1:
        payload["batch_size"] = a.n
    print(f"生成中… ({a.n}枚, steps={steps}, guidance={guidance})", file=sys.stderr)
    studio_generate(payload, a.output)


if __name__ == "__main__":
    main()
