#!/usr/bin/env python3
"""Unsloth の接続先 URL を保存し、疎通を確認する。

例: python set_url.py http://192.168.1.23:8888   # LAN access の Network address を貼り付け
    python set_url.py --reset                     # localhost:8888 に戻す
    python set_url.py                             # 現在の設定と疎通を表示
"""
import os
import re
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _common  # noqa: E402


def main():
    args = sys.argv[1:]
    if not args:
        print(f"現在の接続先: {_common.BASE_URL}")
        sys.exit(0 if _common.check_connection(_common.BASE_URL) else 1)
    if args[0] == "--reset":
        if os.path.exists(_common.URL_FILE):
            os.remove(_common.URL_FILE)
        print(f"接続先を {_common.DEFAULT_URL} に戻しました")
        sys.exit(0 if _common.check_connection(_common.DEFAULT_URL) else 1)

    url = args[0].strip().rstrip("/")
    if not re.match(r"^https?://", url):
        url = "http://" + url
    url = re.sub(r"/(v1|api)(/.*)?$", "", url)  # 末尾にパスが付いていたら除去
    with open(_common.URL_FILE, "w", encoding="utf-8") as f:
        f.write(url + "\n")
    print(f"接続先を保存しました: {url}")
    sys.exit(0 if _common.check_connection(url) else 1)


if __name__ == "__main__":
    main()
