#!/usr/bin/env python3
"""接続先・API キーの状態と、ロード中の画像・動画モデルを表示する。

例: python status.py
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _common  # noqa: E402

if __name__ == "__main__":
    print(f"接続先: {_common.BASE_URL}")
    sys.exit(0 if _common.check_connection() else 1)
