"""Unsloth API 共通ヘルパー（標準ライブラリのみ、localhost:8888 固定・API キー不要）。"""
import base64
import json
import mimetypes
import os
import struct
import sys
import urllib.error
import urllib.request

BASE_URL = "http://localhost:8888"

# 画像生成・編集の既定値（引数で上書き可）
DEFAULT_STEPS = 20
DEFAULT_GUIDANCE = 1.0


def die(msg, code=1):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(code)


def _error_message(raw):
    try:
        body = json.loads(raw)
    except Exception:
        return raw[:500]
    err = body.get("error") or body.get("detail") or body
    if isinstance(err, dict):
        return err.get("message") or json.dumps(err, ensure_ascii=False)
    if isinstance(err, list):  # FastAPI のバリデーションエラー (422)
        return "; ".join(
            f"{'.'.join(str(x) for x in e.get('loc', [])[1:])}: {e.get('msg')}" for e in err
        )
    return str(err)


def request(method, path, payload=None, timeout=600, raw=False):
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(f"{BASE_URL}{path}", data=data, method=method)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read()
            return body if raw else json.loads(body)
    except urllib.error.HTTPError as e:
        msg = _error_message(e.read().decode(errors="replace"))
        hint = ""
        if e.code in (401, 403):
            hint = ("（キーなしアクセスが許可されていません。Unsloth の Settings → API → "
                    "Keyless API access で「Everything else」(localhost のフルアクセス) を有効にしてください）")
        elif e.code == 503 or (e.code == 409 and "load" in msg.lower()):
            hint = "（モデル未ロード。Unsloth の Images/Video 画面でモデルをロードしてください）"
        die(f"HTTP {e.code}{hint}: {msg}")
    except urllib.error.URLError as e:
        die(f"{BASE_URL} に接続できません: {e.reason}。Unsloth が localhost:8888 で起動しているか確認してください")


def image_to_data_url(path):
    if not os.path.isfile(path):
        die(f"画像が見つかりません: {path}")
    mime = mimetypes.guess_type(path)[0] or "image/png"
    with open(path, "rb") as f:
        return f"data:{mime};base64,{base64.b64encode(f.read()).decode()}"


def image_size(path):
    """PNG / JPEG / WebP の幅・高さを返す（不明なら None）。"""
    with open(path, "rb") as f:
        head = f.read(32)
        if head[:8] == b"\x89PNG\r\n\x1a\n":
            return struct.unpack(">II", head[16:24])
        if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
            if head[12:16] == b"VP8X":
                w = int.from_bytes(head[24:27], "little") + 1
                f.seek(27)
                h = int.from_bytes(f.read(3), "little") + 1
                return w, h
            if head[12:16] == b"VP8 ":
                f.seek(26)
                w, h = struct.unpack("<HH", f.read(4))
                return w & 0x3FFF, h & 0x3FFF
            if head[12:16] == b"VP8L":
                b = head[21:25]
                w = 1 + (((b[1] & 0x3F) << 8) | b[0])
                h = 1 + (((b[3] & 0xF) << 10) | (b[2] << 2) | ((b[1] & 0xC0) >> 6))
                return w, h
        if head[:2] == b"\xff\xd8":
            f.seek(2)
            while True:
                marker = f.read(2)
                if len(marker) < 2 or marker[0] != 0xFF:
                    return None
                if marker[1] in (0xC0, 0xC1, 0xC2):
                    f.read(3)
                    h, w = struct.unpack(">HH", f.read(4))
                    return w, h
                (seg_len,) = struct.unpack(">H", f.read(2))
                f.seek(seg_len - 2, 1)
    return None


def fit_size(w, h, max_side=2048):
    """16 の倍数・256〜max_side に収める（縦横比は維持）。"""
    scale = min(1.0, max_side / max(w, h))
    w, h = w * scale, h * scale
    scale = max(1.0, 256 / min(w, h))
    w, h = w * scale, h * scale
    return max(256, int(round(w / 16)) * 16), max(256, int(round(h / 16)) * 16)


def parse_size(size):
    try:
        w, h = (int(x) for x in size.lower().split("x"))
        return w, h
    except Exception:
        die(f"--size は WxH 形式で指定してください（例: 1024x1024）: {size}")


def resolve_defaults(steps, guidance):
    """未指定の steps / guidance を既定値 (20 / 1.0) で埋める。"""
    return (DEFAULT_STEPS if steps is None else steps,
            DEFAULT_GUIDANCE if guidance is None else guidance)


def studio_generate(payload, output):
    """内部 API /api/inference/images/generate で生成し、ギャラリーから PNG を取得して保存。"""
    res = request("POST", "/api/inference/images/generate", payload, timeout=3600)
    images = res.get("images") or []
    if not images:
        die(f"画像が返りませんでした: {res}")
    os.makedirs(os.path.dirname(os.path.abspath(output)), exist_ok=True)
    stem, ext = os.path.splitext(output)
    ext = ext or ".png"
    for i, img in enumerate(images, 1):
        path = f"{stem}{ext}" if len(images) == 1 else f"{stem}_{i}{ext}"
        with open(path, "wb") as f:
            f.write(request("GET", img["url"], timeout=300, raw=True))
        print(f"  seed={img.get('seed')} steps={img.get('steps')} guidance={img.get('guidance')} "
              f"{img.get('width')}x{img.get('height')}", file=sys.stderr)
        print(os.path.abspath(path))  # stdout には保存パスのみ
