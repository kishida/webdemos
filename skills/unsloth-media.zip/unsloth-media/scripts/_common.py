"""Unsloth API 共通ヘルパー（標準ライブラリのみ、localhost:8888 固定・API キー不要）。"""
import base64
import json
import mimetypes
import os
import struct
import sys
import urllib.error
import urllib.request

DEFAULT_URL = "http://localhost:8888"
# 接続先はスキル直下の unsloth_url.txt に保存（set_url.py で設定）。無ければ localhost:8888
URL_FILE = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "unsloth_url.txt")


def _load_url():
    try:
        with open(URL_FILE, encoding="utf-8") as f:
            url = f.read().strip()
            if url:
                return url.rstrip("/")
    except OSError:
        pass
    return DEFAULT_URL


BASE_URL = _load_url()

# API キーはスキル直下の unsloth_key.txt に保存（set_key.py で設定）。無ければ認証ヘッダーなし
KEY_FILE = os.path.join(os.path.dirname(URL_FILE), "unsloth_key.txt")


def _load_key():
    try:
        with open(KEY_FILE, encoding="utf-8") as f:
            return f.read().strip()
    except OSError:
        return ""


API_KEY = _load_key()

_SCRIPTS = os.path.dirname(os.path.abspath(__file__))
ACCESS_GUIDE = f"""接続先: {BASE_URL} / API キー: {"保存済み" if API_KEY else "未設定"}
次の順にユーザーへ確認を依頼してください（1ステップずつ、都度 set_url.py で疎通確認）:
  1. Unsloth が起動しているか
  2. Settings → API → Keyless API access で「Everything else」が ON になっているか
  3. それでも繋がらない場合（Mac では localhost で届かないことが多い）:
     Remote password を設定したうえで LAN access を Start し、
     表示された Network address（例: http://192.168.1.23:8888）をコピーして貼り付けてもらい、
       python {os.path.join(_SCRIPTS, "set_url.py")} <Network address>
     で保存する
  4. HTTP 401 / 403 になる場合（LAN 経由ではキーが必要）:
     Settings → API で「claude-access」という名前の API キーを作成し、
     表示された sk-unsloth-… をコピーして貼り付けてもらい、
       python {os.path.join(_SCRIPTS, "set_key.py")} <API キー>
     で保存する"""

# 画像生成・編集の既定値（引数で上書き可）。ロード中モデルで切り替える。
# (判定関数, 表示名, 通常の steps, タイトル用 --hero の steps)。上から順に評価。
_QWEN21 = ("qwen-image-2.1", "qwen-image-21", "qwen_image_2.1", "qwen_image_21", "qwenimage21", "qwenimage-2.1")
MODEL_STEP_PROFILES = (
    (lambda m: any(k in m for k in _QWEN21) and "turbo" in m, "Qwen-Image-2.1 Turbo", 12, 20),
    (lambda m: any(k in m for k in _QWEN21), "Qwen-Image-2.1", 20, 30),
)
DEFAULT_STEPS = 20       # 上記に当てはまらないモデル
DEFAULT_HERO_STEPS = 30
DEFAULT_GUIDANCE = 1.0


def die(msg, code=1):
    print(f"ERROR: {msg}", file=sys.stderr)
    sys.exit(code)


def _error_message(raw):
    try:
        body = json.loads(raw)
    except Exception:
        return raw[:500]
    err = body.get("error") or body.get("detail") or body
    if isinstance(err, dict):
        return err.get("message") or json.dumps(err, ensure_ascii=False)
    if isinstance(err, list):  # FastAPI のバリデーションエラー (422)
        return "; ".join(
            f"{'.'.join(str(x) for x in e.get('loc', [])[1:])}: {e.get('msg')}" for e in err
        )
    return str(err)


def request(method, path, payload=None, timeout=600, raw=False):
    data = json.dumps(payload).encode() if payload is not None else None
    req = urllib.request.Request(f"{BASE_URL}{path}", data=data, method=method)
    if data is not None:
        req.add_header("Content-Type", "application/json")
    if API_KEY:
        req.add_header("Authorization", f"Bearer {API_KEY}")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = resp.read()
            return body if raw else json.loads(body)
    except urllib.error.HTTPError as e:
        msg = _error_message(e.read().decode(errors="replace"))
        hint = ""
        if e.code in (401, 403):
            hint = ("（API キーが無効です）" if API_KEY else "（キーなしアクセスが許可されていません）") + "\n" + ACCESS_GUIDE
        elif e.code == 503 or (e.code == 409 and "load" in msg.lower()):
            hint = "（モデル未ロード。Unsloth の Images/Video 画面でモデルをロードしてください）"
        die(f"HTTP {e.code}{hint}: {msg}")
    except urllib.error.URLError as e:
        die(f"Unsloth に接続できません ({e.reason})\n" + ACCESS_GUIDE)


def image_to_data_url(path):
    if not os.path.isfile(path):
        die(f"画像が見つかりません: {path}")
    mime = mimetypes.guess_type(path)[0] or "image/png"
    with open(path, "rb") as f:
        return f"data:{mime};base64,{base64.b64encode(f.read()).decode()}"


def image_size(path):
    """PNG / JPEG / WebP の幅・高さを返す（不明なら None）。"""
    with open(path, "rb") as f:
        head = f.read(32)
        if head[:8] == b"\x89PNG\r\n\x1a\n":
            return struct.unpack(">II", head[16:24])
        if head[:4] == b"RIFF" and head[8:12] == b"WEBP":
            if head[12:16] == b"VP8X":
                w = int.from_bytes(head[24:27], "little") + 1
                f.seek(27)
                h = int.from_bytes(f.read(3), "little") + 1
                return w, h
            if head[12:16] == b"VP8 ":
                f.seek(26)
                w, h = struct.unpack("<HH", f.read(4))
                return w & 0x3FFF, h & 0x3FFF
            if head[12:16] == b"VP8L":
                b = head[21:25]
                w = 1 + (((b[1] & 0x3F) << 8) | b[0])
                h = 1 + (((b[3] & 0xF) << 10) | (b[2] << 2) | ((b[1] & 0xC0) >> 6))
                return w, h
        if head[:2] == b"\xff\xd8":
            f.seek(2)
            while True:
                marker = f.read(2)
                if len(marker) < 2 or marker[0] != 0xFF:
                    return None
                if marker[1] in (0xC0, 0xC1, 0xC2):
                    f.read(3)
                    h, w = struct.unpack(">HH", f.read(4))
                    return w, h
                (seg_len,) = struct.unpack(">H", f.read(2))
                f.seek(seg_len - 2, 1)
    return None


def fit_size(w, h, max_side=2048):
    """16 の倍数・256〜max_side に収める（縦横比は維持）。"""
    scale = min(1.0, max_side / max(w, h))
    w, h = w * scale, h * scale
    scale = max(1.0, 256 / min(w, h))
    w, h = w * scale, h * scale
    return max(256, int(round(w / 16)) * 16), max(256, int(round(h / 16)) * 16)


def parse_size(size):
    try:
        w, h = (int(x) for x in size.lower().split("x"))
        return w, h
    except Exception:
        die(f"--size は WxH 形式で指定してください（例: 1024x1024）: {size}")


def model_label(status):
    """status レスポンスから表示用のモデル名を作る。"""
    if not status or not status.get("loaded"):
        return None
    name = status.get("display_repo_id") or status.get("repo_id") or "(不明)"
    extra = [x for x in (status.get("gguf_variant"), status.get("family")) if x]
    return f"{name} ({', '.join(extra)})" if extra else name


def image_status():
    return request("GET", "/api/inference/images/status", timeout=30)


def step_profile(status):
    """ロード中モデルに対応する (プロファイル名, 通常 steps, タイトル用 steps)。"""
    ids = " ".join((status.get(k) or "") for k in ("display_repo_id", "repo_id", "base_repo")).lower()
    for match, label, steps, hero in MODEL_STEP_PROFILES:
        if match(ids):
            return label, steps, hero
    return "その他のモデル", DEFAULT_STEPS, DEFAULT_HERO_STEPS


def resolve_defaults(steps, guidance, hero=False):
    """ロード中モデルを表示し、未指定の steps / guidance を既定値で埋める。

    steps: Qwen-Image-2.1 Turbo → 12（--hero 20）、Qwen-Image-2.1 → 20（--hero 30）、その他 → 20（--hero 30）
    guidance: 1.0
    """
    status = image_status()
    if not status.get("loaded"):
        die("画像モデルがロードされていません。Unsloth の Images 画面でモデルをロードしてください")
    profile, normal, hero_steps = step_profile(status)
    print(f"モデル: {model_label(status)}  [{profile}: 通常 {normal} / タイトル用 {hero_steps} steps]",
          file=sys.stderr)
    if steps is None:
        steps = hero_steps if hero else normal
    return steps, (DEFAULT_GUIDANCE if guidance is None else guidance)


def studio_generate(payload, output):
    """内部 API /api/inference/images/generate で生成し、ギャラリーから PNG を取得して保存。"""
    res = request("POST", "/api/inference/images/generate", payload, timeout=3600)
    images = res.get("images") or []
    if not images:
        die(f"画像が返りませんでした: {res}")
    os.makedirs(os.path.dirname(os.path.abspath(output)), exist_ok=True)
    stem, ext = os.path.splitext(output)
    ext = ext or ".png"
    for i, img in enumerate(images, 1):
        path = f"{stem}{ext}" if len(images) == 1 else f"{stem}_{i}{ext}"
        with open(path, "wb") as f:
            f.write(request("GET", img["url"], timeout=300, raw=True))
        print(f"  seed={img.get('seed')} steps={img.get('steps')} guidance={img.get('guidance')} "
              f"{img.get('width')}x{img.get('height')}", file=sys.stderr)
        print(os.path.abspath(path))  # stdout には保存パスのみ


def _get_json(url, path):
    req = urllib.request.Request(f"{url}{path}")
    if API_KEY:
        req.add_header("Authorization", f"Bearer {API_KEY}")
    with urllib.request.urlopen(req, timeout=10) as r:
        return json.loads(r.read())


def print_loaded_models(url=None):
    """ロード中の画像・動画モデルを表示する。"""
    url = (url or BASE_URL).rstrip("/")
    for kind, path in (("画像", "/api/inference/images/status"), ("動画", "/api/inference/video/status")):
        try:
            status = _get_json(url, path)
        except Exception as e:  # noqa: BLE001
            print(f"  {kind}モデル: 取得できません ({e})")
            continue
        label = model_label(status)
        if not label:
            print(f"  {kind}モデル: 未ロード")
        elif kind == "画像":
            profile, normal, hero = step_profile(status)
            print(f"  {kind}モデル: {label}  [{profile}: 通常 {normal} / タイトル用 {hero} steps]")
        else:
            print(f"  {kind}モデル: {label}")


def check_connection(url=None):
    """疎通確認。結果を表示して True/False を返す（set_url.py / set_key.py 用）。"""
    url = (url or BASE_URL).rstrip("/")
    req = urllib.request.Request(f"{url}/api/inference/images/status")
    if API_KEY:
        req.add_header("Authorization", f"Bearer {API_KEY}")
    key_state = "API キーあり" if API_KEY else "API キーなし"
    try:
        with urllib.request.urlopen(req, timeout=10) as r:
            r.read()
        print(f"OK: {url} に接続できました（{key_state}）")
        print_loaded_models(url)
        return True
    except urllib.error.HTTPError as e:
        if e.code in (401, 403):
            if API_KEY:
                print(f"NG: {url} には届きましたが、API キーが拒否されました (HTTP {e.code})。"
                      "Settings → API で claude-access キーを作り直して貼り付けてもらってください", file=sys.stderr)
            else:
                print(f"NG: {url} には届きましたが、認証が必要です (HTTP {e.code})。"
                      "「Everything else」が ON か確認し、それでも駄目なら Settings → API で "
                      "claude-access という名前の API キーを作成して貼り付けてもらってください", file=sys.stderr)
        else:
            print(f"注意: {url} から HTTP {e.code} が返りました", file=sys.stderr)
    except urllib.error.URLError as e:
        print(f"NG: {url} に接続できません ({e.reason})。Unsloth の起動と、LAN access が Start されているか確認してください",
              file=sys.stderr)
    return False
