#!/usr/bin/env python3
"""Unsloth の API キーを保存し、疎通を確認する。

キーは Unsloth の Settings → API で「claude-access」という名前で作成した sk-unsloth-… を使う。

例: python set_key.py sk-unsloth-xxxx   # 保存して疎通確認
    python set_key.py --clear            # 削除（キーなしアクセスに戻す）
"""
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import _common  # noqa: E402


def main():
    args = sys.argv[1:]
    if not args:
        print(__doc__.strip())
        print(f"\n現在: API キー {'保存済み' if _common.API_KEY else '未設定'}")
        sys.exit(0)
    if args[0] == "--clear":
        if os.path.exists(_common.KEY_FILE):
            os.remove(_common.KEY_FILE)
        _common.API_KEY = ""
        print("API キーを削除しました")
        sys.exit(0 if _common.check_connection() else 1)

    key = args[0].strip().strip('"').strip("'")
    if key.lower().startswith("bearer "):
        key = key[7:].strip()
    if not key.startswith("sk-unsloth-"):
        print("注意: sk-unsloth- で始まっていません。コピー漏れがないか確認してください", file=sys.stderr)
    fd = os.open(_common.KEY_FILE, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(key + "\n")
    _common.API_KEY = key
    print(f"API キーを保存しました（{key[:14]}…）")
    sys.exit(0 if _common.check_connection() else 1)


if __name__ == "__main__":
    main()
