---
name: procedural-lowpoly-trees
description: three.jsのゲームやシーンに、ポリゴンの少ないリアルな木を置くときに使う。神社・寺・公園・庭・街路樹に数本置く場合から、鎮守の森のような大量配置、Unity/Godot向けのOBJ書き出しまで対応。スギ・ヒノキ・クスノキ・イチョウ・クロマツ・サクラ・イロハモミジ・オーク・モミ・シラカバ・ヤナギなど。
---

# ローポリ樹木ライブラリ

`scripts/trees.js` は、既存の three.js シーンに木を足すための部品。シーン・ライト・カメラ・地形は一切持たず、ゲーム側のものにそのまま従う。木はシード付きの手続き生成で、同じ引数なら毎回同じ木になる。

**ライブラリは書き直さないこと。** `scripts/` のファイルを読んでプロジェクトにそのままコピーし、ゲーム側のコードから呼ぶだけにする。動作確認は three.js r128 と r186 で済んでいる。

| ファイル | 使い方 |
|---|---|
| `scripts/trees.js` | 通常の `<script>`。グローバルの `THREE` があれば `window.Trees` が自動で作られる。関数 `createTrees(THREE)` も定義する |
| `scripts/trees.module.js` | ESモジュール。`import createTrees from './trees.module.js'` |
| `examples/shrine.html` | 神社のシーンに木を組み込んだ例(注連縄、鎮守の森を含む) |

1つのHTMLで完結させる必要があるとき(Claudeのアーティファクトなど)は、three.js の `<script>` の後に `trees.js` の中身をそのまま `<script>` として貼る。three.js は `https://cdnjs.cloudflare.com/ajax/libs/three.js/r128/three.min.js` から読める。

## 1本置く

```js
const Trees = createTrees(THREE);            // ESM: import createTrees from './trees.module.js'
const tree = Trees.create('sugi', { x: 9, z: -6, seed: 11 });
scene.add(tree);
```

`create` は普通の `THREE.Object3D`(既定では距離で詳細度が切り替わる `THREE.LOD`)を返す。置いたあとも `position`・`rotation`・`scale` で動かせ、親子付けもできる。

> **俯瞰型のゲームでは `lod: 1` で固定すること。** 見下ろし型・クォータービュー・RTS・シミュレーションのようにカメラが上空から広い範囲を映すゲームでは、画面内の木がカメラから似た距離に並ぶ。そこで距離による詳細度の切り替えを使うと、スクロールやズームのたびに画面の真ん中で木の形が入れ替わって見え、強い違和感が出る。こうした用途では、2番目に細かいモデル(LOD1)に固定する。`create` には `{ lod: 1 }`、`createInstanced` にも `{ lod: 1 }` を渡す。LOD1 は上から見て十分な葉の量があり、三角形はLOD0のおよそ1/3〜1/2で済む。`createInstanced` は詳細度を固定しても `distances.far` より遠い木と画面の後ろ側の木は描かないので、ズームアウトで遠くの木が消える場合は `distances: { far: 1000 }` のように広げる。一人称や三人称の視点で、地面近くから見るゲームだけ `'auto'` のままにする。

### create のオプション

| オプション | 既定値 | 内容 |
|---|---|---|
| `x, y, z` | 0 | 根元の位置。地形があれば地面の高さを `y` に渡す |
| `rot` | 0 | Y軸まわりの回転(ラジアン) |
| `seed` | 1 | 形のバリエーション。同じ樹種を並べるときは変える |
| `height` | 樹種ごと | 高さ(m)。幹の太さも比例して変わる |
| `scale` | 1 | 全体の拡大率 |
| `lod` | `'auto'` | `'auto'` で距離に応じて3段階切り替え。`0`(最も細かい)〜`2` で固定。俯瞰型のゲームでは `1` |
| `lodDistances` | `[高さ×4, 高さ×10]` | LOD1とLOD2に切り替える距離 |
| `shadows` | true | 影を落とし、受ける。シーン側の設定(下記)も必要 |
| `params` | — | 樹種の値を部分的に上書き(例: `{ leafHue: 50, radius: 1.2 }`) |

### 返り値の `userData.tree`

- `height`: 実際の高さ(m)
- `stats`: LOD0〜2の三角形数など
- `trunkAt(h)`: 根元から高さ `h` m の幹の中心(ワールド座標の `position`)と半径 `radius`。注連縄や看板、柵を幹に合わせるときに使う

```js
const at = tree.userData.tree.trunkAt(2.4);
const rope = new THREE.Mesh(new THREE.TorusGeometry(at.radius + 0.12, 0.13, 8, 40), ropeMaterial);
rope.rotation.x = Math.PI / 2; rope.position.copy(at.position); scene.add(rope);
```

## 樹種

| id | 名前 | 既定の高さ | LOD0の三角形 | 向いている場所 |
|---|---|---|---|---|
| `sugi` | スギ | 30 m | 約5,900 | ご神木、参道の並木、鎮守の森 |
| `hinoki` | ヒノキ | 22 m | 約3,800 | 鎮守の森、境内の奥 |
| `kusunoki` | クスノキ | 20 m | 約7,600 | 大きく枝を張るご神木(西日本) |
| `ichou` | イチョウ | 18 m | 約3,500 | 境内、寺。`leafHue: 50` で黄葉 |
| `kuromatsu` | クロマツ | 12 m | 約3,100 | 海辺の神社、庭園 |
| `sakura` | サクラ | 9 m | 約2,900 | 参道、公園 |
| `momiji` | イロハモミジ | 7 m | 約2,900 | 参道、庭。既定は紅葉。`leafHue: 95` で青葉 |
| `oak` | オーク(コナラ) | 9 m | 約3,000 | 里山、公園 |
| `fir` | モミ | 13 m | 約1,700 | 山地 |
| `birch` | シラカバ | 11 m | 約2,100 | 高原、林の縁 |
| `willow` | シダレヤナギ | 8 m | 約4,400 | 水辺、堀 |
| `dead` | 枯れ木 | 8 m | 約1,200 | 荒れた場所。葉なし |
| `shrub` | 低木 | 2.2 m | 約550 | 植え込み、林床 |

LOD1 はLOD0のおよそ1/3〜1/2、LOD2 は1/5〜1/10の三角形になる(針葉樹は減り方が小さい)。`Trees.species` で一覧を取得できる。

## 既存シーンとの関係

- **マテリアル**: `MeshStandardMaterial` に風の揺れと疑似AOを足したもの。シーンのライト・環境光・`scene.fog` にそのまま従う。葉は逆光で少し透ける(1つ目の DirectionalLight を使う)。
- **影**: 木は既定で影を落とし、受ける。葉の影は透過の形どおり(木漏れ日)になる。点光源の影にも対応する。ゲーム側で次の設定が必要:
  ```js
  renderer.shadowMap.enabled = true;
  sun.castShadow = true;            // DirectionalLight
  ground.receiveShadow = true;
  ```
  大きな木は影のカメラ範囲(`sun.shadow.camera.left/right/top/bottom/far`)に収める。
- **色空間**: テクスチャは sRGB として登録する。r128〜r151 では `renderer.outputEncoding = THREE.sRGBEncoding` にしないと暗く見える(r152以降は既定で正しい)。
- **風**: `Trees.wind = 0.35`(0で静止、1で強風)。時間は自動で進む。ゲームを一時停止するときは `Trees.setTime(t)` で手動にする。
- **後片付け**: シーンを破棄するときは `Trees.dispose()` でテクスチャ・ジオメトリ・マテリアルを解放する。同じ樹種・シード・パラメータの木はジオメトリとマテリアルを共有するので、何本作ってもメモリは増えない。

## 神社・寺での使い方の目安

- **ご神木**: `Trees.create('sugi', { height: 38, params: { radius: 1.1, baseSize: 0.38 } })`。`baseSize` を上げると下枝のない幹が長くなる。クスノキなら `height: 16〜22`、`params: { radius: 1.2 }`。
- **注連縄**: `trunkAt(2〜3)` の位置と半径にトーラスを置く。紙垂は半径の少し外に板を下げる。
- **参道**: サクラ、モミジ、イチョウを、シードを変えて左右に数本ずつ。
- **鎮守の森**: 境内を囲むスギ・ヒノキは、次の「たくさん置く」の方法で数百本置く。境内には `create` で数本だけ置く。
- **季節**: `params.leafHue` で色相を変える。モミジ 95(青葉)/6(紅葉)、イチョウ 78(緑)/50(黄葉)、サクラは花の色(345前後)。

## たくさん置く(林・森・並木)

`create` を個別に呼ぶのは、目安として50本まで。それ以上はインスタンシングを使う。

```js
const placements = [{ x: 30, z: -40, scale: 1.1 }, { x: 34, y: 0.5, z: -45 } /* ... */];  // rot は省略するとランダム
const cedars = Trees.createInstanced('sugi', placements, { variants: 3, seed: 20 });
scene.add(cedars);
// 毎フレーム(カメラが動いたときだけ内部で再計算する)
cedars.update(camera);
```

オプション: `variants`(形の種類数、既定3)、`seed`、`height`、`params`、`shadows`、`lod`(`0`〜`2` で詳細度を固定。俯瞰型のゲームでは `1`。省略すると距離で切り替え)、`distances: { l0, l1, far }`(既定は高さの4倍・10倍、250 m)。`cedars.triangles` で描画中の三角形数を取得できる。

地形全体に植生を自動で配置したいときは `Trees.forest.place(envFn, half, seed)` を使う。`envFn(x, z)` は `{ h, s, m, cover, edge, tl, rd }`(標高・傾斜・湿り気・森の被覆度・森の縁・森林限界・川までの距離)を返す関数。戻り値は `{ trees: [{ sp, v, x, z, rot, scale }] }` なので、`sp` ごとにまとめて `createInstanced` に渡す。種の好みは `Trees.forest.suit` を参照し、地形の標高スケールが違う場合は書き換える。

## 他のエンジン(Unity・Godot・Blender)に持っていく

```js
const blob = await Trees.exportZip('kusunoki', { seed: 4, height: 16 });  // create と同じオプション
```

ZIPには LOD0〜2 の OBJ、MTL、樹皮と葉の PNG、設定値の JSON が入る。取り込むときは、葉のマテリアルをアルファのカットアウト(しきい値0.4前後)と両面表示にする。風の揺れはエンジン側のシェーダーで付ける。

## 独自の樹種を作る

`create` の第1引数には、プリセットの代わりにパラメータのオブジェクトも渡せる。既存のプリセットをもとに変えるのが簡単。

```js
const myTree = { ...Trees.presets.kusunoki, name: '大楠', branches: 14, gnarl: 0.7, leafHue: 105 };
scene.add(Trees.create(myTree, { seed: 2 }));
```

主なパラメータ:

| パラメータ | 内容 |
|---|---|
| `height`, `radius` | 高さ、幹の半径(m) |
| `shape` | 樹冠の形。`'0'` 円錐、`'1'` 球、`'2'` 半球、`'3'` 円柱、`'4'` 先細りの円柱、`'5'` 炎形、`'6'` 逆円錐 |
| `baseSize` | 枝が出始める高さ(全体に対する比) |
| `levels`, `branches`, `children2`, `children3` | 分岐の深さ(1〜3)と各段の枝の数 |
| `length1`, `lengthRatio`, `downAngle` | 主枝の長さ、子枝の長さの比、分岐角(度) |
| `gnarl`, `droop`, `upAttr` | 曲がり、しだれ、上に向かう力 |
| `bark` | 樹皮: `oak` `fir` `birch` `willow` `dead` `sugi` `hinoki` `kusunoki` `ichou` `pine` `sakura` `momiji` |
| `leafType` | 葉カードの付き方。`'broad'` 枝先寄り、`'needle'` 枝に沿う |
| `leafTex` | 葉の絵: `broad` `needle` `sugi` `hinoki` `pine` `ginkgo` `maple` `sakura` |
| `leafDensity`, `leafSize`, `leafWidth`, `leafHue` | 枝1 mあたりのカード数、カードの大きさ(m)、葉の幅、色相 |
| `cardMode` | `'cross'`(十字、4三角形)または `'single'`(1枚、2三角形) |
| `radialTrunk`, `radialBranch`, `lenSegTrunk`, `lenSegBranch`, `skipTwigs` | 幹と枝の分割数、最も細い枝をメッシュにしないか |

三角形を減らしたいときは、効果の大きい順に `skipTwigs: true` → `lenSegBranch` と `radialBranch` を下げる → `leafDensity` を下げて `leafSize` を上げる(見かけの葉の量は「枚数×面積」で決まるので、密度を半分にするならサイズを約1.4倍にする)。

## 仕組み(改造するときに)

- **骨格**: Weber–Penn モデルの簡略版。主枝の長さは樹冠形状の関数で決め、枝は黄金角(137.5°)ずつ回して配置する。子枝の太さはパイプモデル(親の半径 ×(長さの比)^1.15)。
- **メッシュ**: 平行移動フレームでねじれない筒を張り、枝先は1点に閉じる。細い枝ほど分割を減らす。
- **葉**: 数十枚の葉を描いた透過カードを並べる。法線を樹冠の楕円体の向きに曲げてふんわりした陰影にし、樹冠の内側ほど暗くする疑似AOを頂点に焼き込む。
- **LOD**: カードを減らした分だけ大きくして「枚数×面積」を保つので、遠くでも葉の量が変わらない。
- **風**: 頂点の高さと幹からの距離だけで揺れ幅を決めるので、枝の付け根が割れない。影の計算にも同じ揺れを入れている。
- 生成の低レベル関数は `Trees.internals`(`genSkeleton`, `genCards`, `buildLOD`, `toGeo`, `barkData`, `leafCanvas`, `objText`, `makeZip`)から使える。パラメータを触って試すエディタを作るときに使う。

## 注意点

- 俯瞰型のゲームでは、詳細度の自動切り替えを使わず `lod: 1` に固定する(「1本置く」の注意書きを参照)。
- 葉のテクスチャは canvas で描くので、ブラウザ(DOM)が必要。Node.js では幹と枝の形状生成(`Trees.internals`)だけ使える。
- 初回の `create` は樹種ごとにテクスチャ生成で数十〜数百ミリ秒かかる。ロード画面のあいだに使う樹種を1本ずつ作っておくと、ゲーム中に引っかからない。
- `lod: 'auto'` の切り替えは three.js の `THREE.LOD` が描画時に自動で行う。`renderer.render` 以外の方法で描く場合は `tree.update(camera)` を呼ぶ。
- クロマツは段状の枝ぶりまでは再現しない。庭園の仕立て松が必要なら、`params` で `branches` や `downAngle` を調整するか、独自の樹種として作る。
