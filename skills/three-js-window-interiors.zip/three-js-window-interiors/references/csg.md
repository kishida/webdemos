# CSG, when it is still the right tool

Window grids should be generated directly (`geometry.md`). CSG remains correct for one-off shapes that are not grids — a car cabin, a landmark, an irregular cut. These rules keep it correct. The failure modes are silent: you get geometry, it is just wrong.

## Rule 1: cutters within one operation must not overlap

A subtraction is *(triangles of A outside B)* + *(triangles of B inside A, flipped)*, which assumes B is a valid closed solid. Merging several boxes into one cutter is fine **while they are disjoint** — they are then components of one valid solid. The moment two overlap, B is self-intersecting and the inside/outside test breaks. The usual symptom is a stray wall: the end cap of one cutter lies inside the other, is judged "inside A", and is emitted as surface.

**Stage the subtractions.** Each stage's cutter must be internally disjoint; stages may overlap freely, because subtracting from already-empty space is the ordinary case. A car cabin is three stages: interior cavity, then side windows, then windscreen and rear — the side and front/rear cutters intersect each other, so they cannot share a stage.

## Rule 2: one evaluation per object, not per feature

Chaining an evaluation per feature accumulates error and drops faces. Batch every disjoint cutter into one merged geometry per stage.

## Rule 3: extra vertex attributes need opting in

Default is `['position', 'uv', 'normal']`. Set `csgEvaluator.attributes` explicitly. Both operands must carry every listed attribute — fill the carved solid with white if it has no meaningful colour. Drop `uv` when nothing samples a texture; it is pure interpolation cost.

## Rule 4: results are in world space

`evaluate()` returns a brush whose geometry is world-space with an identity matrix. Position the *input* brushes; add the result without a position; build anything you align to it in world coordinates. Pass a fresh `new Brush()` as the target.

## Rule 5: chaining with multi-material brushes is safe

Feeding a result (with a material array) back in as A works — `getMaterialList` handles arrays and `consolidateGroups` merges groups sharing a material object. Material index 0 stays the original surface, index 1 the carved surfaces, which lets one carved geometry be shared across instances with a per-instance material array.

## Rule 6: avoid slivers and coplanar faces

Give cutters 0.1–0.15 m of overshoot past the surface they breach so every intersection is transverse. Keep leftover solid remnants above ~0.03 m; a 0.01 m ledge between a window head and a ceiling is legitimate but fragile. Compute the margins before generating.
