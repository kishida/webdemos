# Tuning and diagnosis

## Parameters, in order of impact

| Parameter | Typical | Effect |
|---|---|---|
| Room size vs window size | room ≫ window | Dominates. Shallow or window-sized means flat. |
| Facade shell thickness | 0.45 m | The reveal depth. Near 1 m it becomes a tunnel. |
| Fresnel `minA` | 0.14 clear / 0.45 smoked | Interior visibility head-on |
| Fresnel `maxA` | 0.88 – 0.95 | Mirror strength at grazing angles |
| Room intensity | 0.55 – 0.95 × lit fraction | Mean room brightness after mean-normalization |
| Room occupancy | building 0.5–0.9, tenant ±0.3 (min 0.12) | Share of lit rooms; tune by measured clearly-lit share (~70 %), check the darkest building |
| Lamp on-probability | ~0.8 inside an occupied room | Dim rooms below `pow` 0.5 read as dark from the street |
| Rooms per axis | 1–4, drawn per tenant run of 1–4 floors | One fixed cross per floor reads as a repeating grid on tall buildings |
| Fixture size | 0.42 m | Larger reads as an area light |
| Fixture colour scale | 0.7 with `toneMapped: false` | 1.0 always clips |
| Reveal outer | facade albedo × measured wall radiance per unit albedo | Must equal what the lit wall renders; a fixed fraction of albedo glows on light facades |
| Reveal inner | room colour × pow × 0.45 | Must equal the room's mean |
| `envMapIntensity` | 0.9 – 1.15 | Reflection strength |

Randomize intensity per room, not per building: uniform intensity reads as signage rather than occupancy. Occupancy, on the other hand, should correlate per tenant run of floors — lit and dark *bands* of floors are what real office towers show at night.

## Diagnosis (beyond the table in SKILL.md)

| Report | Cause | Check |
|---|---|---|
| "Too bright" | `toneMapped: false` at full colour | Scale emissive to ~0.7 |
| "Rooms are pitch black" | Dark hex × small intensity | Compute the linear value, not the hex |
| Interior brightens on the sunlit side | Baked surface on `MeshStandardMaterial` | Switch to `MeshBasicMaterial` |
| Faces missing / see-through walls | Winding or normal direction | `geometry.md`, emitting a rectangle |
| Windows sealed, or holes offset | Facade hole and room-wall hole disagree | They must be the same rectangle |
| Frames glow on brick/concrete but not on dark glass towers | Reveal colour is a fixed fraction of albedo | Measure wall radiance (`geometry.md`, Window reveals) |
| "This building has its lights off too much" | Occupancy layers multiplied too low | Count clearly-lit windows over many buildings; raise building occupancy, narrow tenant swing |
| Load got slow after varying room layouts | Field cache keys exploded | Cap lamp count in the key, widen the size bucket (`bake.md`, Caching) |

## Known limits — say these before the user finds them

- **Probes have no parallax.** Captured from a point, so reflections do not shift with the camera. Fine at distance; up close the glass starts to look like a flat sticker. Screen-space reflections or a path tracer are the escalation path.
- **Baked reveals ignore dynamic lights.** Under a street lamp the lit wall brightens and the reveal does not; frames read slightly darker there.
- **A 3×3 field per face cannot hold hotspots.** The bright pool under a lamp cannot appear between samples. A shared lightmap atlas is the next step — room shapes number in the dozens, so one atlas serves every window.

## Load cost

Analytic generation is milliseconds; the ray-traced fields are tens of milliseconds; probes are the largest item, at 6 scene renders each. Keep it in a progress loop and yield after paint:

```js
const afterPaint = () => new Promise(r => requestAnimationFrame(() => {
  const ch = new MessageChannel();          // unclamped macrotask, fires after the frame
  ch.port1.onmessage = () => r();
  ch.port2.postMessage(0);
}));
```

A double `requestAnimationFrame` also works but costs two frames per yield; `setTimeout(0)` is a timer task and can be delayed under load. Gate yields on elapsed time (~140 ms) rather than yielding once per work item — the yield itself is the cost.

## Applying the technique to vehicles

A cabin is not a grid, so CSG is appropriate — but run it **once** and share the geometry, varying only the material array per instance.

- **Full-span cutters.** One box wider than the cabin punches both side windows; one longer box punches windscreen and rear. Pillar widths fall out of the gaps.
- **`DoubleSide` glass**, or you look through the near window and out through the far opening at the world beyond.
- **`castShadow = false` on the glass**, and set it *after* any blanket `traverse(m => m.castShadow = true)`.
- **Smoked glass** wants `minA` near 0.45.
- **Sky-only env map**, since the object moves.
- **Dark cabin shell** — roof and pillars in near-black rather than body colour, one shared material.
- The interior bake works unchanged: a ceiling-lamp model gives a bright floor and dark headliner, which matches a real cabin.
