# Building geometry

Everything is generated directly into position/normal/color arrays. No boolean operations.

## Dimensions

```
shell thickness   0.45     facade wall; also the window reveal depth
floor pitch       2.00
room height       1.70     leaves a 0.30 slab between floors
window opening    upper 3/4 of the room height; lower quarter is a sill
window margin     shell + 0.4    keeps adjacent faces' openings apart at corners
column spacing    1.7            cols = max(1, floor(usable / 1.7))
window width      min(1.25, spacing * 0.62)
partition         0.35 thick; 1-4 rooms per axis, re-chosen per tenant run of floors
```

`usable = faceSpan - 2 * margin`, columns centred on the building axis at
`along = -usable/2 + (c + 0.5) * spacing`. Floor `r` starts at `1.14 + r * 2.0`;
stop when `base + roomHeight > h - 0.3` so the roof stays solid.

## Surfaces to emit

The solid's boundary is exactly these. Emit all of them and the mesh is closed.

| Surface | Group | Notes |
|---|---|---|
| 4 facade walls | facade | tessellated with window holes |
| roof top, bottom face | facade | bottom matters for the shadow pass |
| room floor + ceiling | interior | solid |
| room inner walls (toward partition) | interior | solid |
| room outer walls (on the perimeter) | interior | holes matching the facade |
| window tunnels, 4 quads each | interior | connect facade hole to room-wall hole |

Two material groups: index 0 the facade (plain colour, no vertex colours), index 1 the interior (`MeshBasicMaterial({ vertexColors: true })`). Fill facade vertices with white so a single `color` attribute covers the whole geometry.

The facade hole and the room-wall hole must be the same rectangle; the tunnel spans between them. Any mismatch shows as a visible step.

## Tessellating a wall with holes

Holes lie on a grid, so split into horizontal bands and vertical piers:

```js
function gridWall(u0, u1, v0, v1, holesU, bands) {
  const out = []; let v = v0;
  for (const [vb, vt] of bands) {
    if (vb > v + 1e-6) out.push([u0, u1, v, vb]);      // band between window rows
    let cur = u0;
    for (const [ua, ub] of holesU) {                    // piers between columns
      if (ua > cur + 1e-6) out.push([cur, ua, vb, vt]);
      if (ub > cur) cur = ub;
    }
    if (cur < u1 - 1e-6) out.push([cur, u1, vb, vt]);
    v = vt;
  }
  if (v < v1 - 1e-6) out.push([u0, u1, v, v1]);
  return out;
}
```

A facade passes every floor's `[ybot, ytop]` as bands. A room's outer wall passes only its own floor's band, with holes clipped to that room's span. Empty `bands` yields one full rectangle, which is what solid walls want.

Verify with a script: total rectangle area must equal wall area minus hole area, and no two rectangles may overlap. Both are exact.

## Emitting a rectangle

Axis-aligned quads only. Map `(u, v)` by fixed axis: `ax0 → [fixed, v, u]`, `ax1 → [u, fixed, v]`, `ax2 → [u, v, fixed]`.

With corners in order `A(u0,v0) B(u1,v0) C(u1,v1) D(u0,v1)` the resulting normal is **−X for ax0, −Y for ax1, +Z for ax2**. Swap B and D to flip. Get this wrong and faces vanish under back-face culling — the most likely failure in the whole pipeline, and invisible in any numeric check.

Room walls take the **inward** normal: a room's `+X` wall is emitted with normal `−X`.

Flat per-quad normals suit a low-poly look and let you build a plain triangle soup with no index buffer.

## Partitions and tenants

**Never move windows to suit a partition.** Partitions go into existing gaps between window columns, so the facade grid stays identical on every floor while the rooms behind it change. With the dimensions above the gap is `spacing × 0.38 ≥ 0.65`, always wider than `PART + 0.12`, so a partition in a gap never drops a window.

The partition perpendicular to X is seen through the windows of the ±Z faces, so it follows the ±Z column layout, and vice versa. The two axes are placed independently.

**One cross per floor plate is not enough.** It caps every floor at 2×2 rooms with the same layout on every floor; on a tall building the on/off pattern becomes a visible repeating grid. And a size-driven count (`round(extent / targetRoomSize)`) does not fix it either: on a large plate it saturates at the cap, and one tower measured 4×4 on 21 of 28 floors (the rest 3×4 or open plan), with walls jittered only slightly around even spacing. Draw the count instead, and place walls unevenly:

```js
const MIN_ROOM = 1.4;                                     // ~2.5 m
const N_SMALL = [[1, .10], [2, .45], [3, .30], [4, .15]];
const N_LARGE = [[1, .03], [2, .20], [3, .38], [4, .39]]; // plate extent > 15 (~26 m)
function pickCount(extent) {
  const nMax = Math.max(1, Math.min(4, Math.floor(extent / 2.6)));
  const opts = (extent > 15 ? N_LARGE : N_SMALL).filter(([n]) => n <= nMax);
  let r = rnd() * opts.reduce((a, [, w]) => a + w, 0);
  for (const [n, w] of opts) if ((r -= w) <= 0) return n;
  return opts.at(-1)[0];
}
function partitions(cols, lo, hi, n) {                    // random gaps -> uneven rooms
  const gaps = [];
  for (let i = 0; i < cols.length - 1; i++) {
    const g = (cols[i] + cols[i + 1]) / 2;
    if (g - lo >= MIN_ROOM && hi - g >= MIN_ROOM) gaps.push(g);
  }
  const out = [];
  for (let t = 0; out.length < n - 1 && t < 40 && gaps.length; t++) {
    const g = gaps[Math.floor(rnd() * gaps.length)];
    if (out.every(p => Math.abs(p - g) >= MIN_ROOM + PART)) out.push(g);
  }
  return out.sort((a, b) => a - b);
}
```

**Tenant runs.** Real office floors come in leases: one tenant takes a few consecutive floors with the same plan. Draw a plan, keep it for 1–4 floors, then draw a new one. About 8 % of plans are open plan (no partitions); cap their run at 2 floors, because a 4-floor block of single huge rooms reads as one flat lit slab. Measured tower stack after this change, bottom to top: `2x2 ×3 | 4x1 ×4 | 3x4 | 1x4 | 2x3 ×3 | 4x3 ×4 | 1x1 | 4x2 ×4 | 4x4 ×4 | 2x4 ×3`.

Because each level now has its own intervals, store the window assignment **per level** (each level carries `xI, zI, zW, xW`), and pass per-level hole lists to the facade `gridWall` bands.

Check with a script that the glass pane count per floor is constant after changing the partition logic — it is the cheapest proof that no window was dropped.

**Wide glass (shop fronts).** A storefront window is ~0.86 × spacing wide, so the gap is too narrow for a partition and a partition always overlaps its neighbours. Trim the window back to the room interval instead of dropping it: `ua = max(ua, lo + 0.06)`, `ub = min(ub, hi - 0.06)`, drop only if less than 0.5 remains.

## Lamp layout

Lamps must land on the **window grid**, not on a subdivision of the room. Rooms are asymmetric, so spacing lamps evenly inside a room puts them a quarter of a window-width off — clearly visible through the opening.

For each room, collect the window positions of the two perimeter faces it touches, and place a lamp at every intersection:

```js
q.xs = zFace.cols.filter(c => c.q === q).map(c => c.along); // from the ±Z face
q.zs = xFace.cols.filter(c => c.q === q).map(c => c.along); // from the ±X face
q.lamps = q.xs.flatMap(x => q.zs.map(z => [x, z]));
```

Every window then has a fixture directly in line with it. Room sizes vary, so lamp counts vary naturally (2–6 per room is typical). Fall back to the room centre if a room touches no windows on one axis.

Fixtures are ~0.42 m, `toneMapped: false`, colour × 0.7, positioned at `base + roomHeight - 0.08`.

## Occupancy

Decide **whole-room occupancy first**, then individual lamps. Switching only lamps independently looks right on paper ("a room with every lamp off is unlit"), but a room on the window grid typically has 9–16 lamps, and 0.38¹⁶ is effectively zero — no room ever goes dark, and every window glows.

Three layers, each with a job:

```js
buildingOcc = 0.5 + rnd() * 0.4                               // per building
tenantOcc   = clamp(buildingOcc + rand(-0.3, 0.3), 0.12, 0.97) // per tenant run: lit and dark bands of floors
occupied    = rnd() < tenantOcc                                // per room
lit[k]      = occupied && rnd() < 0.8                          // per lamp, inside an occupied room
pow = lit.some(Boolean) ? rand(0.55, 0.95) * (0.45 + 0.55 * litFraction) : 0
```

The layers multiply, so tune the **result**, not the factors. Instrument the generator and count windows by `pow` over a few dozen buildings: "clearly lit" (`pow ≥ 0.5`), "dim" (`0 < pow < 0.5`), dark. Dim rooms read as dark from the street, so the clearly-lit share is the number that matches what the user sees.

| Setting | building occ | tenant swing / floor | lamp p | clearly lit (mean) | dim | darkest building |
|---|---|---|---|---|---|---|
| too dark | 0.35–0.85 | ±0.45 / 0.03 | 0.62 | 50 % | 16 % | 23 % |
| tuned | 0.50–0.90 | ±0.30 / 0.12 | 0.80 | 70 % | 5 % | 46 % |

The darkest building is the one users screenshot; check the minimum, not only the mean.

## Window reveals

The reveal is the visible wall thickness around the opening, made of the four tunnel quads. Two rules:

- **Match the outer edge to what the lit wall actually renders**, not to a fixed fraction of its colour. The reveal is unlit `MeshBasicMaterial` (baked) while the facade is lit `MeshStandardMaterial`, so the two only meet if the bake equals the wall's rendered radiance: `facadeAlbedo × measuredRadiancePerUnitAlbedo`.
- **Match the inner edge to the room's mean brightness** (`roomColour × pow × 0.45`). A fixed inner value leaves the frame brighter than the room behind it, which reads as a glowing outline.

Interpolate along the tunnel's depth axis between those two.

**Why a fixed factor fails.** A rule like `facadeColour × 0.34` is only right for the lighting it was tuned in. In a darker night scene a white wall rendered at about 0.035 (linear, before tone mapping), so 0.34 was about 10× too bright. The symptom is selective: on a dark facade (albedo ~0.1) 34 % of it is still dark and looks fine, but on brick, concrete or stone (albedo 0.3–0.6) the reveal outshines the wall, so frames glow around windows whose rooms are off. "Dark building fine, light building glows" points straight at this.

**Measure the factor** in the running renderer, once per lighting setup (night and day differ by more than 10×). Render a white `MeshStandardMaterial` plane facing each horizontal direction into a float target with tone mapping off, far from local lights, and read the centre pixel:

```js
const tgt = new THREE.WebGLRenderTarget(4, 4, { type: THREE.FloatType });
const cam = new THREE.PerspectiveCamera(20, 1, 0.1, 20);
const wall = new THREE.Mesh(new THREE.PlaneGeometry(2, 2), new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.9 }));
scene.add(wall); const tm = renderer.toneMapping; renderer.toneMapping = THREE.NoToneMapping;
for (const ry of [0, Math.PI / 2, Math.PI, -Math.PI / 2]) {
  wall.position.set(9000, 5, 9000); wall.rotation.set(0, ry, 0); wall.updateMatrixWorld();
  const n = new THREE.Vector3(0, 0, 1).applyEuler(wall.rotation);
  cam.position.copy(wall.position).addScaledVector(n, 3); cam.lookAt(wall.position);
  renderer.setRenderTarget(tgt); renderer.render(scene, cam);
  const px = new Float32Array(64); renderer.readRenderTargetPixels(tgt, 0, 0, 4, 4, px);
  console.log(ry, px[20], px[21], px[22]);        // linear RGB per unit albedo
}
renderer.setRenderTarget(null); renderer.toneMapping = tm; scene.remove(wall);
```

Example from a moonlit night / sunny day setup:

| | measured white wall | reveal outer edge per unit albedo |
|---|---|---|
| night | 0.017–0.069, mean ~0.035, bluish | `[0.022, 0.025, 0.040]` (×0.8: the recess sees less sky) |
| day, sunlit / shaded | 0.49–0.60 / 0.14–0.18 | sides and soffit `[0.15, 0.16, 0.18]` (mostly shaded); sill, facing up, `[0.38, 0.37, 0.35]` |

Keep the colour tint the measurement gives (moonlight is blue). Bake two colour sets (night, day) and swap the `color` attribute on a time-of-day change.

Limit: the bake cannot follow dynamic lights. Under a street lamp the lit wall brightens but the reveal does not, so frames there read slightly darker than the wall — far less noticeable than a glowing frame, and the right side to err on.

## Merging

One geometry per building, two groups, plus one merged glass mesh and one merged fixture mesh. Three draw calls per building, and frustum culling works per building. Never create a mesh per window.
