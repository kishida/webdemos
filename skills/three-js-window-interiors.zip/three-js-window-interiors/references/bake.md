# Interior lighting bake

## Why trace rays

An analytic falloff (`cos / r²` from a lamp) never sees the shape of the room: no corner darkening, no enclosure, no light escaping the opening. The room reads as a lit surface rather than a lit volume. Tracing is nearly free here — the room is an empty box, so it is ray-box slab intersection against six planes with no BVH.

## Two traps

**Lighting the ceiling.** A ceiling lamp points down. The ceiling is the *darkest* surface in the room; it only receives bounce. Any bake where brightness rises monotonically with height is wrong, and it produces exactly the flat glowing rectangle the whole exercise avoids. If the ceiling is not darkest, the normals are not flipped.

**Re-lighting a baked surface.** Use `MeshBasicMaterial({ vertexColors: true })`. `MeshStandardMaterial` multiplies the bake by scene lighting, so interiors brighten on whichever side the sun hits.

## The tracer

```js
const ROOM_SPP = 192;

function rtExit(lo, hi, o, d) {            // which face does the ray leave through
  let tMin = Infinity, face = -1, sgn = 0;
  for (let a = 0; a < 3; a++) {
    if (Math.abs(d[a]) < 1e-9) continue;
    const t = ((d[a] > 0 ? hi[a] : lo[a]) - o[a]) / d[a];
    if (t > 1e-6 && t < tMin) { tMin = t; face = a; sgn = d[a] > 0 ? 1 : -1; }
  }
  return { t: tMin, face, sgn };
}

function rtDirect(lamps, p, n) {           // empty box → no shadow ray needed
  let s = 0;
  for (const L of lamps) {
    const dx = L[0] - p[0], dy = L[1] - p[1], dz = L[2] - p[2];
    const r2 = dx*dx + dy*dy + dz*dz, r = Math.sqrt(r2) + 1e-6;
    s += Math.max(0, (dx*n[0] + dy*n[1] + dz*n[2]) / r) / (r2 + 0.25);
  }
  return s;
}

function rtShade(lo, hi, lamps, p, n) {    // direct + one bounce
  let ind = 0;
  for (let s = 0; s < ROOM_SPP; s++) {
    const d = cosineDir(n, (s + rnd()) / ROOM_SPP, rnd());
    const e = rtExit(lo, hi, p, d);
    if (e.face < 0) continue;
    const hp = [p[0]+d[0]*e.t, p[1]+d[1]*e.t, p[2]+d[2]*e.t];
    const hn = [0,0,0]; hn[e.face] = -e.sgn;
    ind += 0.5 * rtDirect(lamps, hp, hn);  // albedo 0.5
  }
  return rtDirect(lamps, p, n) + ind / ROOM_SPP;
}
```

Cosine-weighted sampling needs a tangent basis: pick `a = (0,0,1)` unless `|n.z| > 0.9`, then `T = normalize(a × n)`, `B = n × T`. Stratify the first dimension to cut variance. Push sample points inside the box by clamping to `lo + 0.03` / `hi - 0.03` on all three axes — this handles face offset and corner offset in one step.

## Store it as a field, not per vertex

Indexing baked values by vertex index couples the bake to the mesh layout, which breaks the moment geometry is generated analytically. Instead sample **3×3 per face** and read it back by position with bilinear interpolation. Any tessellation can then query it.

```
face order: 0:+X  1:-X  2:+Y ceiling  3:-Y floor  4:+Z  5:-Z
face (u,v): X walls → (z, y);  Y faces → (x, z);  Z walls → (x, y)
```

## Normalize by the mean, not the maximum

Dividing by the maximum crushes almost every visible surface below 0.3 and the room looks dark whatever intensity you pass. Scale so the **mean is 0.45**; the intensity parameter then means "average room brightness" and behaves predictably.

Expected values for a 3.9 m room with a 2×2 lamp grid, after mean normalization:

| Face | min | mean | max |
|---|---|---|---|
| Walls (×4) | 0.29 | 0.50 | 0.82 |
| Ceiling | 0.22 | 0.26 | 0.30 |
| Floor | 0.30 | 0.42 | 0.67 |

Room intensity `rand(0.55, 0.95) × (0.45 + 0.55 × litLampFraction)` keeps the peak near 0.78 — just at the bloom threshold, so only the brightest wall patches glow.

## Caching

Quantize and cache the field. Include **every** varying dimension plus the lamp count:

```js
const key = Math.round(qw/1.5) + '|' + Math.round(qd/1.5) + '|' + Math.round(rh*4) + '|' + nx + 'x' + nz;
```

Omitting height is a real bug: a car cabin (0.39 m tall) and a building room (1.7 m) can share a width/depth bucket and silently get the wrong field. Lamp *positions* need not be in the key — at 3×3 resolution a few tens of centimetres do not show — but lamp *count* changes the distribution and must be.

With one cross partition per floor, a whole city collapses to a few dozen distinct fields, so the bake finishes in tens of milliseconds.

**Varied layouts multiply the keys.** Once room counts and partition positions vary per tenant run (`geometry.md`), room shapes stop repeating. Measured on a 77-building city: 26 keys with one cross per floor → 174 with size-driven counts → 546 with random uneven partitions. Two changes brought it back to 302 keys, ≈1 s at 128 spp:

```js
// Beyond ~4 lamps per row the 3x3 field barely changes, so cap the counts; widen the size bucket.
const key = Math.round(W / 2) + '|' + Math.round(D / 2) + '|' + Math.round(H * 4) + '|' + Math.min(nx, 4) + 'x' + Math.min(nz, 4);
```

Keep height and lamp count in the key (see above) — only *cap* the count.

**Sample count.** `ROOM_SPP` trades load time for noise roughly linearly. Measured relative noise per field sample (12 repeated bakes, 3.9 m room, 2×2 lamps): 192 → 1.5 % mean / 2.6 % worst; 128 → 1.8 % / 3.9 %; 64 → 2.5 % / 5.0 %. Rooms already differ by ±27 % from the random intensity, so 128 is invisible and saves a third of the bake time.

**Lamp model.** The isotropic lamp in `rtDirect` above already leaves the ceiling darkest (measured on that room: ceiling mean 0.26 vs walls 0.50, floor 0.43). A downward-only emission lobe is not needed for that; it mainly shifts light to the floor (floor mean 0.66, walls 0.45, wall minimum down from 0.29 to 0.09).
