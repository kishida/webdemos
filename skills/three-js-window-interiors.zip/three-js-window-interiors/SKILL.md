---
name: three-js-window-interiors
description: Carved interiors behind glass in three.js — real rooms, window openings, baked interior lighting, Fresnel glass and reflection probes. Use for procedural buildings, city, street or skyline scenes, background buildings in any 3D game, lit night windows, facades, glass, "make it look ray traced", fake interiors, or car cabins. Trigger on vague asks like "make the buildings look real" and on symptoms — windows reading as flat, as glowing panels, as decals, or as area lights — with no technique named. Also read before any three-bvh-csg code subtracting more than one box from a solid, since overlapping cutters produce wrong geometry with no error.
---

# Window interiors in three.js

## Diagnose first

| Symptom | Cause | Fix |
|---|---|---|
| Flat glowing rectangles | Interior too shallow → near-uniform back wall | Deepen the interior. Nothing else helps. |
| Mirror, interior invisible | Constant alpha on the glass | Fresnel alpha |
| Painted on, no parallax | No geometry behind the glass | Build real rooms |
| Uncanny, too tidy | Each window has its own window-shaped box | One room shared by several windows |
| Cavernous, empty | One hollow volume per floor | Partition into cells |
| Only the window frame glows | Reveal brighter than the room behind it | Tie both to the same brightness |
| Frames glow around *dark* windows, but only on light facades (brick, concrete), not dark ones | Reveal outer edge set as a fraction of facade **albedo**; at night the lit wall renders far below that fraction | Calibrate the reveal to the wall's measured radiance (`geometry.md`, Window reveals) |
| Lit/dark pattern too regular on large buildings | One cross partition per floor plate, identical on every floor → at most 2×2 rooms | Vary room count and partition position per tenant run of floors (`geometry.md`, Partitions) |
| Whole buildings read dead, or rooms never go fully dark | On/off decided only per lamp (a room with many lamps never goes dark), or occupancy factors stacked too low | Whole-room occupancy per tenant; measure the lit fraction (`geometry.md`, Occupancy) |
| Lamps sit off-centre in the window | Lamps spaced within the room instead of on the window grid | Derive lamp positions from window positions |
| Blooming white blobs | Emissive above the bloom threshold | Budget against the threshold |

Depth dominates. Measured on a 1.35 m window, back-wall brightness range: **0.5 m deep → 0.62–0.72** (uniform, reads as a panel); **1.2 m deep → 0.29–0.94** (reads as a room). You mostly see the back wall; if it is flat, no lighting model rescues it.

If the user proposes lightmaps for window reflections, redirect: lightmaps bake diffuse irradiance and produce zero reflection. They want reflection probes.

## Build the geometry analytically, not with CSG

A facade is a rectangle with a regular grid of rectangular holes. That tessellates directly — horizontal bands between window rows, vertical piers between window columns. **Do not reach for CSG for window openings.** Boolean subtraction costs roughly 5 ms per opening and dominates load time; a mid-size city spends over a minute in it. Direct generation costs milliseconds and lets every building stay unique.

Full geometry recipe, surface inventory and the partition/lamp layout rules: `references/geometry.md`.

CSG is still the right tool for one-off shapes that are not grids — a car cabin, a distinctive landmark. `references/csg.md` covers the staging rules that keep it correct.

## Everything else is load time

Once built, runtime cost is a few draw calls per building plus one transparent pass. If generation takes seconds, add a loading screen — bake in chunks, yield with an after-paint macrotask between them, drive a progress bar, log measured timings. Do not substitute a cheaper approximation on "realtime budget" grounds; that reasoning confuses load cost with frame cost.

## Glass

Constant opacity is the trap: at 0.6 the interior is never visible however bright you make it. Real glass reflects a few percent head-on and nearly everything at grazing angles. Both `vNormal` and `vViewPosition` exist in the `MeshStandardMaterial` fragment shader:

```js
function makeGlassFresnel(minA, maxA) {
  return function (shader) {
    shader.fragmentShader = shader.fragmentShader.replace(
      '#include <dithering_fragment>',
      `#include <dithering_fragment>
       float fres = pow(1.0 - abs(dot(normalize(vNormal), normalize(vViewPosition))), 4.0);
       gl_FragColor.a = mix(${minA.toFixed(2)}, ${maxA.toFixed(2)}, fres);`
    );
  };
}
const glassFresnel = makeGlassFresnel(0.14, 0.88);   // clear
const smokedFresnel = makeGlassFresnel(0.45, 0.95);  // car glass
```

Share **one function object** across materials wanting the same curve — `customProgramCacheKey()` defaults to `onBeforeCompile.toString()`, so identical source means one compiled program instead of hundreds.

`metalness: 1.0` makes the env map the reflection colour directly, `roughness` ~0.05 keeps sun glints sharp, `depthWrite: false` lets the interior show through, `opacity: 1.0` because the shader now owns alpha. Panes sit ~0.012 proud of the facade plane. `FrontSide` for facades; `DoubleSide` only where you would otherwise see straight through the object.

## Reflection probes

```js
const pmrem = new THREE.PMREMGenerator(renderer);
pmrem.compileCubemapShader();

function bakeProbe(x, y, z, size = 128) {
  const rt = new THREE.WebGLCubeRenderTarget(size, { type: THREE.HalfFloatType });
  const cam = new THREE.CubeCamera(1, 1600, rt);
  cam.position.set(x, y, z);
  cam.update(renderer, scene);          // works unparented; updates its own matrix
  const env = pmrem.fromCubemap(rt.texture).texture;
  rt.dispose();
  return env;
}
```

- PMREM is required. A raw cubemap is jagged as soon as roughness rises above 0.
- Hide the glass during the bake, or mirrors reflect mirrors.
- Bake after the static world, before spawning cars and pedestrians.
- **Moving objects get a sky-only probe** captured before the buildings exist. A city probe on a car makes the reflection travel with it, which reads instantly as wrong.
- Assign the nearest probe per building; a 3×3 grid over a block is enough. Each probe is 6 scene renders, so this is the one place where probe count, not resolution, drives cost.

## Bloom

The `UnrealBloomPass` threshold applies to tone-mapped output. `toneMapped: false` means 1.0 always clips and always blooms — if a `MeshBasicMaterial` fixture is a blown-out blob, scale its colour to ~0.7 rather than weakening the bloom. A fixture spanning the whole ceiling *is* an area light and will look like one; keep fixtures ~0.42 m.

## References

- `references/geometry.md` — surfaces to emit, tessellation, partitions and tenants, lamp layout, occupancy, reveal calibration, dimensions.
- `references/bake.md` — the interior ray tracer and the lighting field.
- `references/csg.md` — when CSG is still correct, and how to stage it.
- `references/tuning.md` — parameter ranges, structural limits, vehicle variant.

Prefer arithmetic over guessing: depth, partition clearance, sliver thickness and tessellation area are all checkable with a short script before touching the renderer. When a change targets the look, state the predicted numeric effect.

The same goes for anything that must match the *lit* scene — a baked colour sitting next to a lit surface, or the share of lit windows. Constants copied from another scene are wrong as soon as the lighting differs: measure the real value in the running renderer (render a white test surface to a float target and read it back) and derive the constant from that.
