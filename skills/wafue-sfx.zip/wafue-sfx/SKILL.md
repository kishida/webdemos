---
name: wafue-sfx
description: 尺八・竜笛の物理モデル音源（wafue.js）を、ブラウザゲームや Web ページに組み込んで和風の効果音・ジングル・フレーズを鳴らすためのスキル。音声ファイル不要で、Web Audio だけで本物っぽい息遣い・メリ・裏返り・ヒシギ・吹き捨てが出せる。和風／時代劇／忍者／侍／神社／妖怪／雅楽／和ホラーなど日本的な雰囲気のゲームやアプリを作るとき、タイトル画面・決定音・勝敗ジングル・BGM 的な一節に尺八や笛の音が欲しいときは、ユーザーが「尺八」と言わなくても必ずこのスキルを使うこと。Use for any Japanese-themed browser game or page that needs shakuhachi / ryuteki / bamboo flute sounds, procedural Japanese flute SFX, or synthesized wind-instrument jingles without audio files.
---

# wafue-sfx：尺八・竜笛の物理モデル音源

`scripts/wafue.js`（依存なし・約 21KB）は、尺八と竜笛をデジタル導波管で実時間合成する。
録音素材を使わないので、単一 HTML のゲームにそのまま埋め込める。

## 使い方の流れ

1. **埋め込む**：ゲームの HTML に `<!-- WAFUE -->` と書き、`python3 scripts/inline_into_html.py game.html` を実行して本体を差し込む。
   claude.ai の公開ページなど外部ファイルを読めない環境では、必ずインライン化すること。
   （手で貼るなら `scripts/wafue.js` の中身を `<script>` にそのまま入れる。）
2. **最初のユーザー操作で解錠**：ブラウザの自動再生制限があるので、click / keydown / touchstart の中で `wf.unlock()` を呼ぶ。
3. **ゲームイベントに音を割り当てる**：下の「イベント→音の対応」を参考に、既存フレーズを使うか自作する。
4. **連打される効果音は事前描画**：`Wafue.renderToBuffer(ctx, "confirm")` で AudioBuffer にしておき BufferSource で鳴らす。
   リアルタイムのプレイヤーは単音なので、重なる音はこちらで。
5. 完全な組み込み例は `assets/example.html`。

## API

```js
const wf = Wafue.create({ instrument: "shakuhachi", volume: 0.8, reverb: 0.4 }); // context, destination も渡せる
await wf.unlock();                         // ユーザー操作の中で

wf.play("title");                          // 既存フレーズ。鳴り終わりで resolve する Promise
wf.play([...steps]);                       // 自作フレーズ（下記）
wf.stop();

// 手で吹く（入力に追従させたいとき）
wf.noteOn("ro", { oct: 1, accent: true, bend: -1.5, to: 0, glide: 400 });
wf.bend(-1.2, 180);    // 半音。負がメリ、正がカリ。ms 省略で即時
wf.flip(true);         // 裏返り（竜笛ではヒシギ）。false で戻す
wf.fall(-4, 600);      // 息を抜きながら音程を落として終わる
wf.noteOff();

wf.set({ breath: 0.45, noise: 0.35, mura: 0.4, yuri: 0.35, reverb: 0.4, volume: 0.8 });
wf.setInstrument("ryuteki");

Wafue.renderToBuffer(ctx, phrase, { instrument, reverb, volume, params }); // → AudioBuffer
Wafue.render(phrase, { instrument, sampleRate });   // → { sampleRate, length, channels:[L,R] }（Node でも可）
```

### 音名

| 楽器 | 低い音域（oct:0） | 高い音域（oct:1） | 音（低→高） |
|---|---|---|---|
| shakuhachi（一尺八寸 D 管） | 乙 | 甲 | `ro` ロ D4, `tsu` ツ F4, `re` レ G4, `chi` チ A4, `ri` リ C5 |
| ryuteki | 和（ふくら） | 責 | `roku` 六 E5, `chu` 中 F#5, `shaku` 夕 G5, `jo` 丄 A5, `go` 五 B5, `kan` 干 C#6, `shi` 次 D6 |

カタカナ・漢字の音名、インデックス（0〜）、Hz の数値（50 より大きい値）も使える。

### フレーズのステップ

```js
{ note: "chi", oct: 1, dur: 650,      // 必須は note と dur(ms)
  accent: true,                       // 裏返りから入る強い吹き込み（0.1 秒ほどで自動で戻る）
  bend: -1.8, to: 0, glide: 750,      // メリから持ち上げる（半音）
  flip: true,                         // このステップの間ずっと裏返す／ヒシギ
  fall: -5, fallMs: 900,              // 終わりに息を抜きながら落とす
  gap: 1500,                          // 息を切って休む（ms）。gap も fall もなければ次の音へレガート
  yuri: 0.75,                         // この音だけ揺りを深く／0 で止める
  enbai: false }                      // 竜笛の塩梅（下からすくい上げ）をこの音だけ切る
{ rest: 400 }
```

### 既存フレーズ

- 尺八：`title`（約 8 秒のタイトル画面）、`start`、`confirm`、`cancel`、`victory`、`defeat`、`danger`、`meditation`（静かな本曲風）
- 竜笛：`hishigi`、`title`、`gagaku`、`confirm`、`cancel`

すべてオリジナル。既存の楽曲（民謡や映画・ゲーム音楽）のメロディをそのまま打ち込むのは避け、下の作法で新しく作る。

## イベント→音の対応（目安）

| ゲームの場面 | 推奨 | 理由 |
|---|---|---|
| タイトル・オープニング | `play("title")`、雅楽なら竜笛 `title` | 強い甲で入り、揺らして落とす一連の型が「和」を一瞬で伝える |
| メニュー決定 | 事前描画 `confirm` | 短い一打＋落としは UI を邪魔しない |
| 戻る・キャンセル | 事前描画 `cancel` | メリで暗く短く |
| ステージ開始・ボス登場 | `start`、ボスなら竜笛 `hishigi` | ヒシギは緊張感が強い |
| 勝利／敗北 | `victory` ／ `defeat` | 上昇＋伸ばし／大きな落とし |
| 危険・被弾 | 事前描画 `danger` | 裏返りの連打は警告音になる |
| 探索・静かな場面 | `meditation` を間隔を空けて | 常時鳴らすと疲れるので 20–60 秒おき程度 |

## 「それっぽい」フレーズの作り方

尺八らしさは音の選び方より **息と音程の動き** で決まる。新しいフレーズを書くときは次の型を組み合わせる。

- **音階**：尺八は ロツレチリ（D F G A C）の五音。竜笛は平調系（E F# G A B C# D）。この中だけで書けば外さない。
- **入り方**：大事な音は `bend: -1.5〜-1.8, to: 0` のメリ込みで入る。強調したい高音は `accent: true`。
- **伸ばす音**：1 秒以上なら `yuri: 0.6〜0.8`。ユリは自動で遅れてかかる。
- **終わり方**：フレーズの最後は必ず `fall`（尺八 −1〜−6、竜笛 −0.8 程度）。音を急に切ると素人っぽく聞こえる。
- **速いパッセージ**：100–150ms のレガート（gap なし）で 2〜4 音駆け下りる／駆け上がる。
- **間**：音と音の間の `gap` は 300–1500ms と広めに。和の音は余白で効く。
- **裏返り（flip / accent）は使いすぎない**：1 フレーズ 1〜2 回まで。竜笛のヒシギは冒頭に 1 回が定石。
- **竜笛**：塩梅が自動でかかる。ユリは控えめ（楽器側で 1/3 に縮小済み）。テンポは尺八よりさらに遅く。

例：オリジナルの短いジングル（宝箱を開けた）

```js
wf.play([
  { note: "re", dur: 120 }, { note: "chi", dur: 120 },
  { note: "ri", dur: 900, bend: -1, to: 0, glide: 300, yuri: 0.6, fall: -2, fallMs: 700, gap: 800 },
]);
```

## 注意

- 音量は既定 0.8 で、ピークはおよそ −8dBFS。ゲーム側の BGM と合わせて `volume` で調整する。
- `breath` を 0.7 以上にすると発振が不安定になり音が暴れる。表現として使うのでなければ 0.3–0.6 に収める。
- モバイルでは ScriptProcessor の負荷を下げるため `bufferSize: 2048` も可（遅延は増える）。
- 音色を変えたい、楽器を足したい、挙動がおかしいときは `references/model.md` を読む。
  ノイズ量・吹き終わり・裏返りの強さはユーザーと聴いて決めた値なので、理由を読まずに戻さない。
