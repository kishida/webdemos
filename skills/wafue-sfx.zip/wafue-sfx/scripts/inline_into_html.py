#!/usr/bin/env python3
"""HTML 内の <!-- WAFUE --> マーカー（または <script src="wafue.js"></script>）を
wafue.js 本体の <script> に置き換え、外部ファイルなしの単一 HTML にする。

  python3 inline_into_html.py game.html            # 上書き
  python3 inline_into_html.py game.html out.html
"""
import re, sys, pathlib
here = pathlib.Path(__file__).resolve().parent
lib = (here / "wafue.js").read_text(encoding="utf-8")
src = pathlib.Path(sys.argv[1]); dst = pathlib.Path(sys.argv[2]) if len(sys.argv) > 2 else src
html = src.read_text(encoding="utf-8")
tag = "<script>\n" + lib.replace("</script", "<\\/script") + "\n</script>"
new, n = re.subn(r'<!--\s*WAFUE\s*-->|<script\s+src=["\'][^"\']*wafue\.js["\']\s*>\s*</script>', lambda m: tag, html, count=1)
if n == 0:
    sys.exit("marker not found: put <!-- WAFUE --> before your game script")
dst.write_text(new, encoding="utf-8")
print(f"inlined wafue.js ({len(lib)//1024} KB) -> {dst}")
