/*!
 * wafue.js — 尺八・竜笛の物理モデル音源（デジタル導波管 / STK Flute 系）
 * 依存なし・単一ファイル。ブラウザ（Web Audio）と Node（オフライン描画）の両方で動く。
 *
 *   const wf = Wafue.create({ instrument: "shakuhachi" });   // or "ryuteki"
 *   button.onclick = () => { wf.unlock(); wf.play("title"); };
 *
 * API は SKILL.md、モデルの中身は references/model.md を参照。
 */
(function (root) {
  "use strict";

  // ------------------------------------------------------------------ instruments
  // tuneK / tuneC は Node で実測した音程補正（len = tuneK*sr/f - tuneC）。
  // pole やジェット比を変えたら scripts/calibrate.js で測り直すこと。
  const INSTRUMENTS = {
    shakuhachi: {
      label: "尺八", reg: ["乙", "甲"], flipName: "裏返り",
      notes: [
        { id: "ro", k: "ロ", f: 293.66 }, { id: "tsu", k: "ツ", f: 349.23 },
        { id: "re", k: "レ", f: 392.0 }, { id: "chi", k: "チ", f: 440.0 },
        { id: "ri", k: "リ", f: 523.25 },
      ],
      tuneK: 1.0136 / 0.6667, tuneC: 2, pole: 0.70,
      breathBase: 0.88, breathRange: 0.22, octBoost: 0.06,
      tame: 1, vibScale: 1, noiseScale: 1, enbai: false,
      defaults: { breath: 0.45, noise: 0.35, mura: 0.4, yuri: 0.35, reverb: 0.4 },
    },
    ryuteki: {
      label: "竜笛", reg: ["和", "責"], flipName: "ヒシギ",
      notes: [
        { id: "roku", k: "六", f: 659.26 }, { id: "chu", k: "中", f: 739.99 },
        { id: "shaku", k: "夕", f: 783.99 }, { id: "jo", k: "丄", f: 880.0 },
        { id: "go", k: "五", f: 987.77 }, { id: "kan", k: "干", f: 1108.73 },
        { id: "shi", k: "次", f: 1174.66 },
      ],
      tuneK: 1.5126, tuneC: 0.84, pole: 0.55,
      breathBase: 0.93, breathRange: 0.17, octBoost: 0.05,
      tame: 0.25, vibScale: 0.35, noiseScale: 0.85, enbai: true,
      defaults: { breath: 0.45, noise: 0.35, mura: 0.4, yuri: 0.35, reverb: 0.45 },
    },
  };

  // ------------------------------------------------------------------ voice (DSP)
  const N = 8192;
  const BASE_JET = 0.32, FLIP_JET = 0.1, UNFLIP_JET = 0.45; // flip = 3 倍音モードへの跳躍
  const FLOOR = 0.86; // 発振閾値のすぐ上。リリース中はここまで息を下げて鳴らし続ける

  class Voice {
    constructor(sr, instrument) {
      this.sr = sr; this.n = 0; this.queue = [];
      this.bore = new Float32Array(N); this.jet = new Float32Array(N);
      this.bw = 0; this.jw = 0; this.lp = 0; this.dcx = 0; this.dcy = 0;
      this.env = 0; this.on = false; this.breath = 0; this.amp = 0; this.airAmp = 0;
      this.held = 0; this.relT = 10; this.vibPhase = 0; this.vibRamp = 0;
      this.mur = 0; this.dip = 0; this.scoop = 0;
      this.jetRatio = BASE_JET; this.unflipT = 0; this.userFlip = false; this.autoUnflipT = 0; this.accentT = 0;
      this.flipMix = 0; this.flipLp = 0; this.nb1 = 0; this.nb2 = 0;
      this.hz = 293.66; this.oct = 0;
      this.bendFrom = 0; this.bendTo = 0; this.bendStart = 0; this.bendDur = 0; this.bendCurve = "out"; this.bendCur = 0;
      this.fallDark = 0;
      this.setInstrument(instrument);
      this.hz = this.I.notes[0].f;
      this._control();
      this.curLen = this.targetLen; this.lpPole = this.lpPoleT;
    }
    setInstrument(name) {
      const I = INSTRUMENTS[name]; if (!I) throw new Error("unknown instrument: " + name);
      this.I = I; this.name = name;
      this.params = Object.assign({}, I.defaults);
    }
    set(p) { for (const k in p) if (k in this.params) this.params[k] = p[k]; }
    lenFor(f) { return this.I.tuneK * this.sr / f - this.I.tuneC; }

    // ---- scheduling (sample-accurate) ----
    at(sample, fn) {
      const q = this.queue; let i = q.length;
      while (i > 0 && q[i - 1].at > sample) i--;
      q.splice(i, 0, { at: sample, fn });
    }
    clear() { this.queue.length = 0; }

    // ---- performance actions ----
    noteOn(hz, o) {
      o = o || {};
      const legato = this.on;
      this.hz = hz; this.oct = o.oct ? 1 : 0;
      this.bendNow(o.bend || 0);
      this.fallDark = 0;
      if (this.I.enbai && o.enbai !== false && !o.accent) this.scoop = legato ? -0.55 : -0.9;
      if (o.accent) this.accent();
      else if (legato) { this.dip = 0.12; this.mur = Math.max(this.mur, this.params.mura * 0.15); }
      else this.mur = this.params.mura;
      this.on = true;
    }
    noteOff() { this.on = false; }
    bendNow(semi) { this.bendFrom = this.bendTo = this.bendCur = semi; this.bendDur = 0; }
    glideTo(semi, ms, curve) {
      this.bendFrom = this.bendCur; this.bendTo = semi; this.bendStart = this.n;
      this.bendDur = Math.max(1, ms * this.sr / 1000); this.bendCurve = curve || "out";
    }
    fall(semi, ms) { this.noteOff(); this.fallDark = Math.min(0.2, -semi * 0.04); this.glideTo(this.bendCur + semi, ms, "in"); }
    accent() {
      this.accentT = 0.03; this.dip = -0.16;
      this.mur = Math.max(this.mur, 0.25 + this.params.mura * 0.6);
      this._flip(true); this.flipMix = 0.2;
      this.autoUnflipT = 0.09 + Math.random() * 0.05;
    }
    flip(on) { this.userFlip = on; if (on || this.autoUnflipT <= 0) this._flip(on); }
    _flip(on) {
      if (on) { this.jetRatio = FLIP_JET; this.mur = Math.max(this.mur, 0.12); this.dip = Math.max(this.dip, 0.08); }
      else if (this.jetRatio !== BASE_JET) { this.jetRatio = BASE_JET; this.unflipT = 0.09; this.dip = Math.max(this.dip, 0.06); }
    }
    silent() { return !this.on && this.amp < 1e-4 && this.airAmp < 1e-4 && !this.queue.length; }

    // ---- control-rate update (every 64 samples) ----
    _control() {
      if (this.bendDur > 0) {
        const p = Math.min(1, (this.n - this.bendStart) / this.bendDur);
        const s = this.bendCurve === "in" ? p * p : this.bendCurve === "linear" ? p : 1 - (1 - p) * (1 - p);
        this.bendCur = this.bendFrom + (this.bendTo - this.bendFrom) * s;
        if (p >= 1) this.bendDur = 0;
      }
      const I = this.I, P = this.params, meri = Math.min(2, Math.max(0, -this.bendCur));
      const f = this.hz * (this.oct ? 2 : 1) * Math.pow(2, this.bendCur / 12);
      this.targetLen = this.lenFor(f);
      this.lpPoleT = Math.min(0.92, I.pole + meri * 0.07 + (this.on ? 0 : this.fallDark));
      this.breathMax = I.breathBase + P.breath * I.breathRange + (this.oct ? I.octBoost : 0) - meri * 0.02;
      this.noiseAmt = P.noise * I.noiseScale;
      this.vibDepth = P.yuri * I.vibScale;
    }

    rd(buf, w, d) { let p = w - d; while (p < 0) p += N; const i = p | 0, fr = p - i; const a = buf[i % N]; return a + (buf[(i + 1) % N] - a) * fr; }

    process(out, off, len) {
      const sr = this.sr;
      const atk = 1 - Math.exp(-1 / (0.06 * sr)), atkHard = 1 - Math.exp(-1 / (0.008 * sr));
      const ampAtk = 1 - Math.exp(-1 / (0.03 * sr)), ampRel = Math.exp(-1 / (0.28 * sr)), airRel = Math.exp(-1 / (0.38 * sr));
      const brSmooth = 1 - Math.exp(-1 / (0.05 * sr)), glide = 1 - Math.exp(-1 / (0.018 * sr)), pole = 1 - Math.exp(-1 / (0.05 * sr));
      const vibInc = 2 * Math.PI * 5.1 / sr, q = this.queue;
      for (let i = off; i < off + len; i++) {
        while (q.length && q[0].at <= this.n) q.shift().fn();
        if ((this.n & 63) === 0) this._control();
        this.n++;
        const on = this.on;
        if (on) { this.held += 1 / sr; this.relT = 0; } else { this.held = 0; this.relT += 1 / sr; }
        // ユリ：伸ばして 0.4 秒ほどしてからかかり始める
        const vr = this.held > 0.4 ? Math.min(1, (this.held - 0.4) / 0.8) : 0;
        this.vibRamp += (vr - this.vibRamp) * 0.0005;
        this.vibPhase += vibInc * (1 + 0.08 * Math.sin(this.vibPhase * 0.13));
        const vib = Math.sin(this.vibPhase) * this.vibDepth * this.vibRamp;

        if (on) {
          this.env += (1 - this.env) * (this.accentT > 0 ? atkHard : atk);
          if (this.accentT > 0) this.accentT -= 1 / sr;
          if (this.autoUnflipT > 0) { this.autoUnflipT -= 1 / sr; if (this.autoUnflipT <= 0 && !this.userFlip) this._flip(false); }
          this.breath = this.env * this.breathMax * (1 + vib * 0.05) * (1 - this.dip);
          this.amp += (1 - this.amp) * (this.accentT > 0 ? atkHard : ampAtk); this.airAmp += (1 - this.airAmp) * ampAtk;
        } else {
          // 吹き終わり：息を発振閾値の少し上まで下げて鳴らし続けながら音量を抜く（急に切れない）
          this.env *= 0.99995;
          const tgt = this.relT < 1.0 ? FLOOR + (Math.max(this.breathMax, FLOOR) - FLOOR) * Math.exp(-this.relT / 0.15) : 0;
          this.breath += (tgt - this.breath) * brSmooth;
          this.amp *= ampRel; this.airAmp *= airRel;
        }
        this.curLen += (this.targetLen - this.curLen) * glide;
        this.lpPole += (this.lpPoleT - this.lpPole) * pole;
        const sag = on ? 0 : 1 - this.amp;           // 息が尽きるにつれ少し下がって暗くなる
        this.scoop *= 0.99985;                      // 塩梅：下からすくい上げ
        const boreLen = this.curLen * (1 - vib * 0.004 + sag * 0.009 - this.scoop * 0.0578);
        if (this.unflipT > 0) this.unflipT -= 1 / sr;
        const jetLen = boreLen * (this.unflipT > 0 ? UNFLIP_JET : this.jetRatio);
        const lpPole = Math.min(0.92, this.lpPole + sag * 0.12);

        this.mur *= 0.99985; this.dip *= 0.9993;
        const turb = (Math.random() * 2 - 1) * (0.02 + this.noiseAmt * 0.045 + this.mur * 0.22);

        // --- waveguide: 息圧 → ジェット遅延 → 三次の非線形 → 管 → 損失 → 反射 ---
        const boreOut = this.rd(this.bore, this.bw, boreLen);
        this.lp = (1 - lpPole) * boreOut + lpPole * this.lp;
        let t = -this.lp;
        const y = t - this.dcx + 0.995 * this.dcy; this.dcx = t; this.dcy = y; t = y;
        const pd = this.breath * (1 + turb) - 0.5 * t;
        this.jet[this.jw] = pd; const jo = this.rd(this.jet, this.jw, jetLen); this.jw = (this.jw + 1) % N;
        let jt = jo * (jo * jo - 1); if (jt > 1) jt = 1; else if (jt < -1) jt = -1;
        this.bore[this.bw] = jt + 0.5 * t; this.bw = (this.bw + 1) % N;

        // --- 息の層（帯域を絞ったノイズ） ---
        const w2 = Math.random() * 2 - 1;
        this.nb1 += 0.35 * (w2 - this.nb1); this.nb2 += 0.04 * (this.nb1 - this.nb2);
        const air = (this.nb1 - this.nb2) * this.airAmp * (0.02 + this.noiseAmt * 0.11 + this.mur * 0.25);

        // --- 裏返り音は高く耳に刺さるので、音量と高域を抑える（竜笛のヒシギは抑えめ） ---
        const fm = this.jetRatio < 0.2 ? ((this.autoUnflipT > 0 && !this.userFlip) ? 0.2 : this.I.tame) : 0;
        this.flipMix += (fm - this.flipMix) * (fm > this.flipMix ? 0.0008 : 0.0015);
        let tone = boreOut * 0.22 * this.amp;
        this.flipLp += 0.22 * (tone - this.flipLp);
        tone = tone + (this.flipLp * 0.42 - tone) * this.flipMix;
        out[i] = tone + air;
      }
    }
  }

  // ------------------------------------------------------------------ post: EQ + reverb + limiter
  class Post {
    constructor(sr) {
      const s = sr / 44100;
      const mk = ls => ls.map(l => ({ b: new Float32Array(Math.round(l * s)), i: 0, f: 0 }));
      this.cL = mk([1116, 1188, 1277, 1356]); this.cR = mk([1139, 1211, 1300, 1379]);
      this.aL = mk([556, 441]); this.aR = mk([579, 464]);
      this.hp = 0; this.hpx = 0; this.lp = 0; this.wet = 0.4;
      this.hpA = Math.exp(-2 * Math.PI * 120 / sr); this.lpA = 1 - Math.exp(-2 * Math.PI * 5200 / sr);
    }
    comb(c, x) { const o = c.b[c.i]; c.f = o * 0.8 + c.f * 0.2; c.b[c.i] = x + c.f * 0.84; c.i = (c.i + 1) % c.b.length; return o; }
    ap(a, x) { const o = a.b[a.i]; a.b[a.i] = x + o * 0.5; a.i = (a.i + 1) % a.b.length; return o - x; }
    run(mono, L, R, off, len, volume) {
      const wet = this.wet, dry = 1 - wet * 0.35;
      for (let i = off; i < off + len; i++) {
        let x = mono[i];
        const h = this.hpA * (this.hp + x - this.hpx); this.hpx = x; this.hp = h; x = h;
        this.lp += this.lpA * (x - this.lp); x = this.lp;
        const inp = x * 0.03;
        let l = 0, r = 0;
        for (let k = 0; k < 4; k++) { l += this.comb(this.cL[k], inp); r += this.comb(this.cR[k], inp); }
        for (let k = 0; k < 2; k++) { l = this.ap(this.aL[k], l); r = this.ap(this.aR[k], r); }
        L[i] = Math.tanh((x * dry + l * wet * 1.6) * volume * 1.4);
        R[i] = Math.tanh((x * dry + r * wet * 1.6) * volume * 1.4);
      }
    }
  }

  // ------------------------------------------------------------------ phrases
  // ステップ:
  //  { note:"ro"|"ロ"|音のindex|Hz(>50), oct:0|1 (甲/責), dur:ms, accent:bool (裏返りから入る強い吹き込み),
  //    bend:開始時の曲げ(半音, 負=メリ), to:曲げの終点, glide:ms,
  //    flip:bool (このステップ中ずっと裏返す/ヒシギ), fall:半音(負), fallMs:ms,
  //    gap:ms (息を切って休む), yuri:0..1 (この音だけ揺りを上書き), enbai:false (竜笛の塩梅を切る) }
  //  { rest: ms }
  // gap も fall もない連続ステップはレガート（息を切らずに指だけ替える）になる。
  const PHRASES = {
    shakuhachi: {
      title: [
        { note: "chi", oct: 1, dur: 650, accent: true },
        { note: "re", oct: 1, dur: 110 }, { note: "tsu", oct: 1, dur: 110 },
        { note: "ro", oct: 1, dur: 1700, yuri: 0.75, fall: -5, fallMs: 900, gap: 1500 },
        { note: "ro", dur: 2500, bend: -1.8, to: 0, glide: 750, yuri: 0.75, fall: -1.2, fallMs: 1100, gap: 1300 },
        { note: "ro", oct: 1, dur: 270, accent: true, yuri: 0, fall: -4, fallMs: 550, gap: 1500 },
      ],
      confirm: [{ note: "ro", oct: 1, dur: 160, accent: true, fall: -3, fallMs: 420, gap: 900 }],
      cancel: [{ note: "ro", dur: 260, bend: -1.4, fall: -1.5, fallMs: 400, gap: 900 }],
      start: [
        { note: "ro", dur: 700, bend: -1.6, to: 0, glide: 500 },
        { note: "ro", oct: 1, dur: 900, accent: true, fall: -2, fallMs: 700, gap: 1200 },
      ],
      victory: [
        { note: "tsu", dur: 140 }, { note: "re", dur: 140 }, { note: "chi", dur: 140 }, { note: "ri", dur: 160 },
        { note: "ro", oct: 1, dur: 1600, accent: true, yuri: 0.7, fall: -1, fallMs: 900, gap: 1300 },
      ],
      defeat: [
        { note: "chi", oct: 1, dur: 600, fall: -6, fallMs: 1200, gap: 700 },
        { note: "ro", dur: 2200, bend: -0.6, to: -2, glide: 1800, yuri: 0.5, fall: -2, fallMs: 1200, gap: 1500 },
      ],
      danger: [
        { note: "ri", oct: 1, dur: 120, accent: true, gap: 90 },
        { note: "ri", oct: 1, dur: 120, accent: true, gap: 90 },
        { note: "chi", oct: 1, dur: 700, flip: true, fall: -3, fallMs: 600, gap: 900 },
      ],
      meditation: [
        { note: "ro", dur: 2600, bend: -1.6, to: 0, glide: 900, gap: 500 },
        { note: "tsu", dur: 1400 }, { note: "re", dur: 2200, gap: 450 },
        { note: "tsu", dur: 1800, bend: -1, gap: 350 },
        { note: "ro", dur: 2600, fall: -1, fallMs: 1200, gap: 1500 },
      ],
    },
    ryuteki: {
      hishigi: [{ note: "roku", dur: 1300, accent: true, flip: true }, { note: "roku", dur: 1500, gap: 1200 }],
      title: [
        { note: "roku", dur: 1300, accent: true, flip: true }, { note: "roku", dur: 1500, gap: 350 },
        { note: "jo", dur: 1300 }, { note: "go", dur: 2300, gap: 300 },
        { note: "jo", dur: 800 }, { note: "go", dur: 800 },
        { note: "roku", oct: 1, dur: 2400, fall: -0.8, fallMs: 900, gap: 1500 },
      ],
      gagaku: [
        { note: "jo", dur: 1300 }, { note: "go", dur: 2300, gap: 300 },
        { note: "jo", dur: 800 }, { note: "go", dur: 800 }, { note: "roku", oct: 1, dur: 2400, gap: 400 },
        { note: "shi", dur: 900 }, { note: "go", dur: 1300 }, { note: "jo", dur: 1500, gap: 350 },
        { note: "shaku", dur: 700 }, { note: "roku", dur: 3400, fall: -0.8, fallMs: 900, gap: 1500 },
      ],
      confirm: [{ note: "roku", oct: 1, dur: 200, accent: true, fall: -1.5, fallMs: 400, gap: 900 }],
      cancel: [{ note: "go", dur: 300, fall: -1, fallMs: 400, gap: 900 }],
    },
  };

  // ------------------------------------------------------------------ helpers
  function resolveHz(I, note) {
    if (typeof note === "number") return note > 50 ? note : I.notes[note].f;
    const n = I.notes.find(x => x.id === note || x.k === note);
    if (!n) throw new Error("unknown note for " + I.label + ": " + note + " (use " + I.notes.map(x => x.id).join("/") + ")");
    return n.f;
  }
  function getPhrase(instrument, phrase) {
    if (Array.isArray(phrase)) return phrase;
    const p = PHRASES[instrument] && PHRASES[instrument][phrase];
    if (!p) throw new Error("unknown phrase: " + instrument + "/" + phrase);
    return p;
  }
  // フレーズをサンプル時刻のイベント列にする。戻り値は「鳴り終わり」のサンプル時刻。
  function schedulePhrase(v, steps, t0) {
    const sr = v.sr, ms = x => Math.round(x * sr / 1000), baseYuri = v.params.yuri;
    let t = t0, tail = 0;
    steps.forEach((s, idx) => {
      if (s.rest != null) { v.at(t, () => v.noteOff()); t += ms(s.rest); return; }
      const hz = resolveHz(v.I, s.note), dur = s.dur || 500;
      v.at(t, () => {
        v.set({ yuri: s.yuri != null ? s.yuri : baseYuri });
        v.noteOn(hz, { oct: s.oct, accent: s.accent, bend: s.bend || 0, enbai: s.enbai });
        if (s.to != null && s.to !== (s.bend || 0)) v.glideTo(s.to, s.glide || dur * 0.4, "out");
        if (s.flip) v.flip(true);
      });
      t += ms(dur);
      const last = idx === steps.length - 1;
      v.at(t, () => {
        if (s.flip) v.flip(false);
        if (s.fall) v.fall(s.fall, s.fallMs || 600);
        else if (s.gap || last) v.noteOff();
      });
      if (s.gap) t += ms(s.gap);
      if (last) tail = s.gap ? 0 : ms(1200);
    });
    v.at(t, () => v.set({ yuri: baseYuri }));
    return t + tail;
  }

  // ------------------------------------------------------------------ offline render
  // ブラウザでも Node でも動く。連打する効果音は起動時に renderToBuffer で AudioBuffer にしておくと軽い。
  function render(phrase, opts) {
    opts = opts || {};
    const instrument = opts.instrument || "shakuhachi", sr = opts.sampleRate || 44100;
    const v = new Voice(sr, instrument); if (opts.params) v.set(opts.params);
    const end = schedulePhrase(v, getPhrase(instrument, phrase), Math.round(0.02 * sr));
    const total = Math.min(Math.round((opts.maxSeconds || 30) * sr), end + Math.round(2.5 * sr));
    const mono = new Float32Array(total), L = new Float32Array(total), R = new Float32Array(total);
    const post = new Post(sr); post.wet = opts.reverb != null ? opts.reverb : v.params.reverb;
    const vol = opts.volume != null ? opts.volume : 0.8, B = 512;
    for (let o = 0; o < total; o += B) { const n = Math.min(B, total - o); v.process(mono, o, n); post.run(mono, L, R, o, n, vol); }
    let last = total - 1; while (last > 0 && Math.abs(L[last]) < 1e-4 && Math.abs(R[last]) < 1e-4) last--;
    const len = Math.min(total, last + Math.round(0.05 * sr));
    return { sampleRate: sr, length: len, channels: [L.slice(0, len), R.slice(0, len)] };
  }
  function renderToBuffer(ctx, phrase, opts) {
    const r = render(phrase, Object.assign({ sampleRate: ctx.sampleRate }, opts));
    const buf = ctx.createBuffer(2, r.length, r.sampleRate);
    buf.getChannelData(0).set(r.channels[0]); buf.getChannelData(1).set(r.channels[1]);
    return buf;
  }

  // ------------------------------------------------------------------ realtime player
  function create(opts) {
    opts = opts || {};
    const AC = root.AudioContext || root.webkitAudioContext;
    const ctx = opts.context || new AC({ latencyHint: "interactive" });
    let instrument = opts.instrument || "shakuhachi";
    const v = new Voice(ctx.sampleRate, instrument);
    if (opts.params) v.set(opts.params);
    const post = new Post(ctx.sampleRate); post.wet = opts.reverb != null ? opts.reverb : v.params.reverb;
    let volume = opts.volume != null ? opts.volume : 0.8, idle = true, pending = [];
    const B = opts.bufferSize || 1024;
    // ScriptProcessor を使う理由：AudioWorklet の Blob URL は CSP の厳しいホストで弾かれることがあるため
    const sp = ctx.createScriptProcessor(B, 0, 2), mono = new Float32Array(B);
    sp.onaudioprocess = e => {
      const L = e.outputBuffer.getChannelData(0), R = e.outputBuffer.getChannelData(1);
      if (idle && v.silent()) { L.fill(0); R.fill(0); v.n += B; flush(); return; }
      v.process(mono, 0, B); post.run(mono, L, R, 0, B, volume);
      idle = v.silent() && Math.abs(L[B - 1]) < 1e-5;
      flush();
    };
    function flush() { if (pending.length) pending = pending.filter(p => { if (v.n >= p.end) { p.resolve(); return false; } return true; }); }
    sp.connect(opts.destination || ctx.destination);
    const lead = () => v.n + Math.round(0.005 * ctx.sampleRate);
    const act = fn => { idle = false; v.at(lead(), fn); };

    const api = {
      context: ctx, node: sp,
      get instrument() { return instrument; },
      /** ユーザー操作（click/keydown/touch）の中で一度呼ぶ。自動再生制限の解除。 */
      unlock() { return ctx.state !== "running" ? ctx.resume() : Promise.resolve(); },
      setInstrument(name) { api.stop(); instrument = name; v.setInstrument(name); v.hz = v.I.notes[0].f; v._control(); v.curLen = v.targetLen; },
      set(p) { if (p.reverb != null) post.wet = p.reverb; if (p.volume != null) volume = p.volume; v.set(p); },
      notes() { return v.I.notes.map(n => n.id); },
      noteOn(note, o) { o = o || {}; const hz = resolveHz(v.I, note); act(() => { v.noteOn(hz, o); if (o.to != null) v.glideTo(o.to, o.glide || 300, "out"); }); },
      noteOff() { act(() => v.noteOff()); },
      bend(semi, ms, curve) { act(() => ms ? v.glideTo(semi, ms, curve) : v.bendNow(semi)); },
      fall(semi, ms) { act(() => v.fall(semi == null ? -4 : semi, ms || 600)); },
      flip(on) { act(() => v.flip(on !== false)); },
      /** フレーズ名か配列を演奏。鳴り終わりで resolve する Promise を返す。 */
      play(phrase, o) {
        o = o || {}; if (o.interrupt !== false) api.stop();
        idle = false;
        const end = schedulePhrase(v, getPhrase(instrument, phrase), lead());
        return new Promise(resolve => pending.push({ end, resolve }));
      },
      stop() { v.clear(); v.flip(false); v.noteOff(); pending.forEach(p => p.resolve()); pending = []; },
      disconnect() { api.stop(); sp.disconnect(); },
    };
    return api;
  }

  const Wafue = { create, render, renderToBuffer, INSTRUMENTS, PHRASES, Voice, version: "1.0.0" };
  if (typeof module !== "undefined" && module.exports) module.exports = Wafue;
  else root.Wafue = Wafue;
})(typeof globalThis !== "undefined" ? globalThis : this);
