#!/usr/bin/env node
/*
 * 新しい楽器プリセットの音程補正（tuneK / tuneC）を実測で求める。
 *
 *   node calibrate.js --pole 0.6 --lo 500 --hi 2000
 *   node calibrate.js --check shakuhachi        # 既存プリセットのズレをセント単位で表示
 *
 * 仕組み：補正なしで鳴らして実際の基音を測り、
 *   sr/f_measured = (len + c)/A  を最小二乗でフィットして  len = A*sr/f - c  を得る。
 * pole（損失フィルタ）を変えるとフィルタの群遅延が変わり音程がずれるので、必ず測り直す。
 */
const path = require("path");
const W = require(path.join(__dirname, "wafue.js"));

const args = process.argv.slice(2);
const opt = (k, d) => { const i = args.indexOf("--" + k); return i >= 0 ? args[i + 1] : d; };
const SR = 48000;

function measure(samples) {
  // 末尾 8192 サンプルを窓かけ DFT。60–4000Hz で最大ピーク→放物線補間
  const W_ = 8192, s = samples.slice(samples.length - W_);
  let px = 0, py = 0; for (let i = 0; i < W_; i++) { const y = s[i] - px + 0.99 * py; px = s[i]; py = y; s[i] = y * (0.5 - 0.5 * Math.cos(2 * Math.PI * i / W_)); }
  const mag = f => { let re = 0, im = 0; const w = 2 * Math.PI * f / SR; for (let i = 0; i < W_; i++) { re += s[i] * Math.cos(w * i); im += s[i] * Math.sin(w * i); } return Math.hypot(re, im); };
  let best = 0, bf = 0; for (let f = 60; f < 4000; f += 3) { const m = mag(f); if (m > best) { best = m; bf = f; } }
  let lo = bf - 3, hi = bf + 3; for (let k = 0; k < 20; k++) { const a = lo + (hi - lo) / 3, b = hi - (hi - lo) / 3; if (mag(a) < mag(b)) lo = a; else hi = b; }
  return (lo + hi) / 2;
}
function play(inst, hz, oct) {
  const v = new W.Voice(SR, inst); v.set({ yuri: 0, noise: 0.1, mura: 0 });
  v.noteOn(hz, { oct, enbai: false }); const o = new Float32Array(SR); v.process(o, 0, SR); return Array.from(o);
}

if (opt("check")) {
  const inst = opt("check"), I = W.INSTRUMENTS[inst];
  for (const n of I.notes) for (const oct of [0, 1]) {
    const tgt = n.f * (oct ? 2 : 1), m = measure(play(inst, n.f, oct));
    console.log(`${n.k}${oct ? "(" + I.reg[1] + ")" : ""}`.padEnd(6), tgt.toFixed(1).padStart(7), "→", m.toFixed(1).padStart(7), (1200 * Math.log2(m / tgt)).toFixed(1).padStart(6) + "c");
  }
  process.exit(0);
}

const pole = +opt("pole", 0.7), lo = +opt("lo", 300), hi = +opt("hi", 1200);
W.INSTRUMENTS.__cal = Object.assign({}, W.INSTRUMENTS.shakuhachi, { pole, tuneK: 1.5, tuneC: 0, enbai: false, notes: [{ id: "x", k: "x", f: lo }] });
const xs = [], ys = [];
for (let i = 0; i < 6; i++) {
  const f = lo * Math.pow(hi / lo, i / 5), len = 1.5 * SR / f;
  const m = measure(play("__cal", f, 0));
  xs.push(len); ys.push(SR / m);
  console.log(`len ${len.toFixed(2)}  measured ${m.toFixed(1)} Hz`);
}
const n = xs.length, mx = xs.reduce((a, b) => a + b) / n, my = ys.reduce((a, b) => a + b) / n;
let sxy = 0, sxx = 0; for (let i = 0; i < n; i++) { sxy += (xs[i] - mx) * (ys[i] - my); sxx += (xs[i] - mx) ** 2; }
const slope = sxy / sxx, icpt = my - slope * mx, A = 1 / slope, c = icpt * A;
console.log(`\npole=${pole}  →  tuneK: ${A.toFixed(4)}, tuneC: ${c.toFixed(3)}`);
