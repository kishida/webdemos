---
name: fm-synth
description: ブラウザ（Web Audio / AudioWorklet）で動く4オペレータFM音源（YM2612/メガドライブ風）を使って、ゲームやWebアプリにBGM・効果音・ジングルを付ける。ユーザーがゲームの音楽、BGM、効果音、SE、ジングル、FM音源、チップチューン、レトロゲーム風サウンド、Web Audio での音作りを求めたとき、またはHTML/JSのゲームやアプリに音が必要になったときは、音声ファイルを探したり生成したりする前にこのスキルを使うこと。音声ファイル不要で、コードだけで作曲・音色設計・効果音作成ができる。
---

# FM音源で BGM・効果音を作る

`assets/` のエンジンをプロジェクトにコピーし、曲データと効果音を JavaScript で書く。
音声ファイルは使わず、AudioWorklet が 4オペレータFM をサンプル単位で合成する。

## 同梱ファイル

| ファイル | 役割 |
|---|---|
| `assets/fm-worklet.js` | DSP 本体。YM2612 の 8 アルゴリズム、op1 フィードバック、オペレータごとの ADSR、ビブラート、ピッチスイープ。`fmWorkletMain()` で包んであるので Blob URL から読み込める（file:// でも動く） |
| `assets/fm-audio.js` | グローバル `FM`。音色ライブラリ、ステップシーケンサー、記譜ヘルパー、効果音プリセット、ミキサー、レベル計測 |
| `assets/demo.html` | 全音色・全効果音・サンプル曲の試聴ページ。曲の書き方のテンプレートでもある |

## 組み込み手順

1. `fm-worklet.js` と `fm-audio.js` をプロジェクトの `js/` などにコピーする（**読み込み順はこの順**）
   ```html
   <script src="js/fm-worklet.js"></script>
   <script src="js/fm-audio.js"></script>
   ```
   ES モジュールのプロジェクトでも、この 2 ファイルは通常の `<script>` で読み込む（`window.FM` を参照）
2. **ユーザー操作の中で** `FM.init()` を呼ぶ（ブラウザの自動再生制限）。最初のキー入力/クリックで呼び、そのキーでゲームを開始させない工夫をする（解錠フレームは入力を捨てる等）
3. `FM.play(song)` で BGM、`FM.play_sfx('explosion', { x })` で効果音
4. ミュート（`FM.toggleMute()`）のキー割り当てを用意しておく

ゲーム固有の音色や効果音は、エンジンを書き換えずに `FM.addPatches({...})` / `FM.defineSfx(name, steps)` で追加する。

## API

```js
await FM.init({ musicVoices: 16, sfxVoices: 12, echo: 0.22 }); // 音楽と効果音は別ノード（効果音で曲が途切れない）
FM.play(song, { mute: { lead: true } });   // トラック名でミュート（タイトル画面で伴奏だけ流す等）
FM.stop();            // リリースを残して停止。FM.stop(true) で即時無音
FM.onSongEnd = (song) => {};               // once:true の曲が終わったとき
FM.play_sfx('shot', { x: px, width: 960 });  // x から定位（パン）を計算
FM.note('sfx', 'bell', 'E6', { dur: 0.3, vel: 0.8, pan: 0, sweep: 0 }); // 単発ノート。freq は数値=Hz、文字列=音名
FM.setVolume({ music: 0.8, sfx: 0.9 }); FM.toggleMute();
await FM.shutdown();  // 全停止して AudioContext を閉じる
await FM.measure('music', 1000);  // → { peak, rms, nonFinite } 出力レベル検証用
```

## 曲データ

```js
const song = {
  bpm: 144, steps: 256,           // steps = 曲の長さ（16分音符単位、1小節16）。ループする
  once: false,                    // true でジングル（1回再生）
  tracks: [
    { name: 'bass',  patch: 'bass',  ev: [...], vel: 1, pan: 0 },
    { name: 'drums', ev: FM.parseDrums('k . h . s . h . k . k h s . h o', 16) },
  ],
};
// ev の要素: { step, len, midi }  ドラムは { step, drum: 'k'|'s'|'h'|'o'|'t' }。個別に vel / patch も指定可
```

記譜ヘルパー（`demo.html` の `buildDemoSong()` が完全な例）:

- `FM.parseBars(['A4 - - . C5 - E5 - ...', ...])` — 1 トークン = 1 ステップ。`-` は前の音を伸ばす、`.` は休符。1 小節 16 トークンでないと console.warn が出るので必ず確認する
- `FM.accomp(['Am','F','C','G'], { bassStep: 2, bassOct: true, chordSteps: [2,6,10,14], chordLen: 2 })` — 1 小節 1 コードでベースと和音（`{bass, chords}`）を生成。`unit: 8` で半小節ごと
- `FM.arpeggio(prog, { pattern: [0,1,2,3,2,1], octave: 12 })` — コードトーンのアルペジオ
- `FM.chord('Em7')` → MIDI 配列。対応: `'' m 7 m7 maj7 dim aug sus2 sus4 add9 m7b5`、ルートに `#`/`b`
- `FM.parseDrums(barPattern, nBars)` — `k` キック, `s` スネア, `h` ハット, `o` オープンハット, `t` タム。`kh` のように同時打ち可

### 作曲の指針

- 曲は 8〜16 小節のループで十分。A（4〜8 小節）+ B（4〜8 小節）で単調さを避ける
- 典型的な構成: ベース（8 分でオクターブ往復）+ 和音（裏拍の刻み）+ リード + ドラム（+ ベルのアルペジオ）
- 場面ごとに曲を変える: タイトル（`mute` で伴奏のみ）、道中、ボス（BPM を上げ、16 分ベース）、クリア/ゲームオーバー（`once: true` のジングル）
- 世界観に合わせて音色を選ぶ: スチームパンク → brass + organ（蒸気オルガン）、SF → lead + strings + slapbass、ファンタジー → strings + bell + epiano
- リードのメロディはコードトーンを拍頭に置くと破綻しにくい

## 音色（patch）

内蔵: `brass organ epiano strings lead bass slapbass bell kick snare hat ohat tom zap blip boom bigboom clank whistle siren noise`

```js
FM.addPatches({ myLead: { alg: 4, fb: 5, vol: 0.2, vib: 0.006, ops: [
  FM.op(1, 0.9, 0.04, 0.4, 0.55, 0.12),   // op(mul, lvl, ar, dr, sl, rr, dt)
  FM.op(1, 0.75, 0.015, 0.5, 0.8, 0.12),
  FM.op(1, 0.65, 0.05, 0.4, 0.5, 0.12, 0.004),
  FM.op(1, 0.6, 0.02, 0.5, 0.8, 0.12, 0.004)] } });
```

- `alg` 0〜7（YM2612 と同じ。キャリア: 0〜3 は op4 のみ / 4 は op2,op4 / 5,6 は op2〜4 / 7 は全部）
- `fb` op1 の自己フィードバック。3〜6 で倍音が増え、8〜9 でノイズになる（爆発、スネア、蒸気音に使う）
- `lvl` キャリアなら音量、モジュレータなら変調指数（×π rad）。モジュレータの `dr`/`sl` を小さくすると音の立ち上がりだけ明るくなる（金属・撥弦の質感）
- `mul` 周波数比。整数比なら楽音、非整数比（3.5, 4.7 など）なら鐘や金属音
- `ar/dr/rr` は秒、`sl` は 0〜1、`dt` はわずかなデチューン（0.003 程度でコーラス感）
- `vib` ビブラートの深さ（0.006〜0.012）、`vol` はパッチ全体の音量

## 効果音

内蔵プリセット: `shot laser eshot hit explosion bigexplosion damage powerup coin jump extend select cancel warning whistle steam bomb`

```js
// 各ステップ: [patch, Hz|'音名', 遅延(秒), 長さ(秒), vel, sweep, panSign]
FM.defineSfx('charge', [['zap', 400, 0, 0.6, 0.7, 4], ['bell', 'C7', 0.6, 0.2, 0.8, 0]]);
```

- `sweep` は長さの間に周波数が何倍になるか（0 = なし）。0.2〜0.4 で下降（ショット、爆発）、1.5〜4 で上昇（ジャンプ、チャージ）
- ノイズ系（boom/noise）は低い周波数ほど重い音になる
- 連射音は vel を 0.5〜0.6 程度に抑え、爆発は x 座標から定位を付けると聞き分けやすい
- 和音や分散和音（powerup/extend）は bell を 50〜80ms 間隔で並べる

## 検証

音は聴けないので、数値と画面で確かめる。

1. `parseBars` の console.warn（小節の長さ違い）とエラーがないことを確認する
2. 再生中に `await FM.measure('music')` / `FM.measure('sfx')` を実行し、`peak` が 0.05〜0.9 程度で `nonFinite: 0` であることを確認する。peak が 0 ならノートが届いていない（`init` 前の呼び出し、patch 名の誤りなど）
3. ブラウザペインが非表示だと `requestAnimationFrame` が止まるので、ゲームのテストはループ関数を JS から直接回す（音のスケジューラは setInterval なので影響しない）
4. **テストが終わったら必ず `FM.shutdown()` で音を止める**（ユーザーの環境で鳴り続けるため）
5. 音色の好みやバランスは聴かないと判断できないので、`demo.html` を開いて試聴してもらうよう伝える

## 落とし穴

- `fm-audio.js` を `fm-worklet.js` より先に読み込むと `init` が失敗する
- AudioWorklet 内のフレーム番号は `currentFrame` に同期済み。ノートの時刻は `FM.ctx.currentTime` 基準の秒で渡す
- パッチを `init` 後に追加するときは必ず `FM.addPatches` を使う（ワークレットへ転送されるため）。`FM.PATCHES` を直接書き換えても反映されない
- 同時発音数を超えると古い音（リリース中を優先）から奪う。和音の多い曲は `musicVoices` を増やす
